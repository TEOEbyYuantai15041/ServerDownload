package com.teoe.wdl;

import com.mojang.serialization.Codec;
import java.io.DataOutputStream;
import java.io.File;
import net.minecraft.class_155;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2841;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_6903;
import net.minecraft.class_7522;
import net.minecraft.class_7924;

public class RegionSaver {

    public static void saveChunkToRegion(File regionDir, class_1923 pos, class_2487 chunkNbt) {
        int regionX = pos.field_9181 >> 5;
        int regionZ = pos.field_9180 >> 5;
        File mcaFile = new File(regionDir, "r." + regionX + "." + regionZ + ".mca");

        try {
            // 使用 Minecraft 原生的 RegionFile 系统自动写入 .mca
            try (net.minecraft.class_2861 region = new net.minecraft.class_2861(new net.minecraft.class_9240("wdl", net.minecraft.class_5321.method_29179(net.minecraft.class_7924.field_41223, net.minecraft.class_2960.method_60655("minecraft", "overworld")), "chunks"), mcaFile.toPath(), regionDir.toPath(), true)) {
                try (DataOutputStream out = region.method_21881(pos)) {
                    net.minecraft.class_2507.method_55324(chunkNbt, out);
                }
                region.method_26981(); // Force sync to disk to prevent data loss on crash/disconnect
            }
        } catch (Exception e) {
            System.err.println("Failed to save chunk " + pos);
            e.printStackTrace();
        }
    }

    public static class_2487 serializeClientChunk(class_638 world, class_2818 chunk, net.minecraft.class_5455 registryManager) {
        class_2487 root = new class_2487();
        root.method_10569("DataVersion", class_155.method_16673().comp_4026().comp_4038());
        root.method_10569("xPos", chunk.method_12004().field_9181);
        root.method_10569("zPos", chunk.method_12004().field_9180);
        root.method_10569("yPos", chunk.method_31607());
        root.method_10582("Status", "minecraft:full"); // 标记为完整区块

        class_6903<class_2520> ops = class_6903.method_46632(class_2509.field_11560, registryManager);
        class_2378<class_1959> biomeRegistry = registryManager.method_30530(class_7924.field_41236);

        class_2499 sectionsList = new class_2499();
        class_2826[] sections = chunk.method_12006();

        // 遍历区块所有的 16x16x16 小节，并使用自带的编解码器转换为标准 NBT
        for (int y = 0; y < sections.length; y++) {
            class_2826 section = sections[y];
            if (section.method_38292()) continue;

            class_2487 sectionNbt = new class_2487();
            sectionNbt.method_10567("Y", (byte) chunk.method_31604(y));

            // 序列化方块 (BlockStates)
            class_2841<class_2680> blockStates = section.method_12265();
            Codec<class_7522<class_2680>> blockCodec = class_2841.method_44347(
                class_2248.field_10651, class_2680.field_24734, class_2841.class_6563.field_34569, class_2246.field_10124.method_9564()
            );
            blockCodec.encodeStart(ops, blockStates).result().ifPresent(elem -> sectionNbt.method_10566("block_states", elem));

            // 序列化群系 (Biomes)
            class_7522<class_6880<class_1959>> biomes = section.method_38294();
            Codec<class_7522<class_6880<class_1959>>> biomeCodec = class_2841.method_44347(
                biomeRegistry.method_40295(), biomeRegistry.method_40294(), class_2841.class_6563.field_34570, biomeRegistry.method_46747(class_1972.field_9451)
            );
            biomeCodec.encodeStart(ops, biomes).result().ifPresent(elem -> sectionNbt.method_10566("biomes", elem));

            sectionsList.add(sectionNbt);
        }
        root.method_10566("sections", sectionsList);

        // 保存方块实体 (如箱子内容、告示牌文字)
        class_2499 blockEntitiesList = new class_2499();
        for (class_2586 be : chunk.method_12214().values()) {
            net.minecraft.class_2338 pos = be.method_11016();
            if (DownloadManager.savedBlockEntitiesCache.containsKey(pos)) {
                blockEntitiesList.add(DownloadManager.savedBlockEntitiesCache.get(pos));
            } else {
                class_2487 beNbt = be.method_38242(registryManager);
                blockEntitiesList.add(beNbt);
            }
        }
        root.method_10566("block_entities", blockEntitiesList);

        return root;
    }
}