package com.teoe.wdl.mixin;

import com.teoe.wdl.DownloadManager;
import com.teoe.wdl.tracker.ChestTracker;
import net.minecraft.class_2649;
import net.minecraft.class_2815;
import net.minecraft.class_310;
import net.minecraft.class_3944;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class NetworkHandlerMixin {
    
    @Inject(method = "onOpenScreen", at = @At("HEAD"), cancellable = true)
    private void onOpenScreen(class_3944 packet, CallbackInfo ci) {
        if (DownloadManager.isRecording() && com.teoe.wdl.tracker.ChestAura.currentTarget != null) {
            if (com.teoe.wdl.tracker.ChestAura.waitingForSync) {
                com.teoe.wdl.tracker.ChestAura.currentSyncId = packet.method_17592();
                com.teoe.wdl.tracker.ChestAura.waitingForSync = false;
                com.teoe.wdl.tracker.ChestAura.waitingForInventory = true;
                ci.cancel(); // Prevent the screen from opening
            }
        }
    }

    @Inject(method = "onInventory", at = @At("HEAD"), cancellable = true)
    private void onInventoryHead(class_2649 packet, CallbackInfo ci) {
        if (DownloadManager.isRecording() && com.teoe.wdl.tracker.ChestAura.currentTarget != null) {
            if (com.teoe.wdl.tracker.ChestAura.waitingForInventory && packet.comp_3837() == com.teoe.wdl.tracker.ChestAura.currentSyncId) {
                // We got the inventory data silently!
                ChestTracker.saveContainerDirectly(com.teoe.wdl.tracker.ChestAura.currentTarget, packet.comp_3839());
                
                // Close the screen on the server
                class_310 client = class_310.method_1551();
                if (client.method_1562() != null) {
                    client.method_1562().method_52787(new class_2815(packet.comp_3837()));
                }
                
                com.teoe.wdl.tracker.ChestAura.currentTarget = null;
                com.teoe.wdl.tracker.ChestAura.waitingForInventory = false;
                ci.cancel(); // Prevent the inventory from updating the local screen handler (which doesn't exist)
            }
        }
    }

    @Inject(method = "onInventory", at = @At("RETURN"))
    private void onInventoryReceived(class_2649 packet, CallbackInfo ci) {
        if (DownloadManager.isRecording()) {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && client.field_1724.field_7512 != null) {
                // Ignore player inventory syncs to avoid overriding chest saves
                if (client.field_1724.field_7512 == client.field_1724.field_7498) {
                    return;
                }
                
                // If the syncId matches, it means the inventory is fully loaded
                if (packet.comp_3837() == client.field_1724.field_7512.field_7763) {
                    ChestTracker.saveCurrentContainer(client.field_1724.field_7512);
                    
                    // If ChestAura opened this automatically, close it immediately now that we have the items
                    if (com.teoe.wdl.tracker.ChestAura.currentTarget != null) {
                        client.execute(() -> {
                            if (client.field_1724 != null) {
                                client.field_1724.method_7346();
                            }
                            if (client.field_1755 != null) {
                                client.method_1507(null);
                            }
                        });
                    }
                }
            }
        }
    }
}