package com.teoe.wdl.mixin;

import com.teoe.wdl.DownloadManager;
import net.minecraft.class_2818;
import net.minecraft.class_631;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_631.class)
public class ChunkDataMixin {
    @Inject(method = "loadChunkFromPacket", at = @At("RETURN"))
    private void onChunkLoad(int x, int z, net.minecraft.class_2540 buf, java.util.Map heightmaps, java.util.function.Consumer consumer, CallbackInfoReturnable<class_2818> cir) {
        if (DownloadManager.isRecording()) {
            class_2818 chunk = cir.getReturnValue();
            if (chunk != null) {
                DownloadManager.onChunkReceived(chunk);
            }
        }
    }
}