package com.teoe.wdl.mixin;

import com.teoe.wdl.DownloadManager;
import com.teoe.wdl.tracker.ChestTracker;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class InteractionMixin {
    @Inject(method = "interactBlock", at = @At("HEAD"))
    private void onInteractBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (DownloadManager.isRecording()) {
            ChestTracker.lastClickedBlock = hitResult.method_17777();
        }
    }
}