package com.teoe.wdl;

import com.teoe.wdl.tracker.ChestTracker;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import java.util.Set;

public class DownloadManager {
    private static boolean isRecording = false;
    public static long currentSeed = 0;
    
    public static final Map<class_2338, class_2487> savedBlockEntitiesCache = new ConcurrentHashMap<>();
    public static final Set<class_1923> historicallySavedChunks = ConcurrentHashMap.newKeySet();
    public static final Set<class_2338> discoveredChests = ConcurrentHashMap.newKeySet();
    private static final BlockingQueue<Runnable> saveQueue = new LinkedBlockingQueue<>();
    private static Thread saveThread;

    private static net.minecraft.class_5455 cachedRegistryManager;

    public static void startRecording() {
        isRecording = true;
        com.teoe.wdl.server.MapGenerator.clear();

        historicallySavedChunks.clear();
        discoveredChests.clear();
        saveQueue.clear();
        savedBlockEntitiesCache.clear();
        ChestTracker.ignoredChests.clear();
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            cachedRegistryManager = client.field_1687.method_30349();
            
            // Save currently loaded chunks immediately
            int viewDistance = client.field_1690.method_38521();
            class_1923 centerPos = client.field_1724.method_31476();
            String dimension = client.field_1687.method_27983().method_29177().method_12832();
            
            for (int x = -viewDistance; x <= viewDistance; x++) {
                for (int z = -viewDistance; z <= viewDistance; z++) {
                    net.minecraft.class_2818 chunk = client.field_1687.method_2935().method_12126(centerPos.field_9181 + x, centerPos.field_9180 + z, false);
                    if (chunk != null) {
                        queueChunkSave(dimension, chunk);
                    }
                }
            }
        }
        startSaveThread();
    }
    
    public static void startRecording(long seed) {
        currentSeed = seed;
        startRecording();
    }

    private static void startSaveThread() {
        if (saveThread == null || !saveThread.isAlive()) {
            saveThread = new Thread(() -> {
                while (isRecording || !saveQueue.isEmpty()) {
                    try {
                        Runnable task = saveQueue.poll(1, java.util.concurrent.TimeUnit.SECONDS);
                        if (task != null) {
                            task.run();
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, "TeoeWDL-Save-Thread");
            saveThread.start();
        }
    }

    public static void stopRecording() {
        if (!isRecording) return;
        isRecording = false;
        
        class_310 client = class_310.method_1551();
        class_2487 playerNbt = null;
        int spawnX = 0, spawnY = 0, spawnZ = 0;
        String playerUuid = null;
        
        if (client.field_1724 != null && cachedRegistryManager != null) {
            spawnX = (int) client.field_1724.method_23317();
            spawnY = (int) client.field_1724.method_23318();
            spawnZ = (int) client.field_1724.method_23321();
            playerUuid = client.field_1724.method_5845();
            
            net.minecraft.class_11362 writeView = net.minecraft.class_11362.method_71459(net.minecraft.class_8942.field_60348, cachedRegistryManager);
            if (!client.field_1724.method_5786(writeView)) {
                client.field_1724.method_5647(writeView);
            }
            playerNbt = writeView.method_71475();
            playerNbt.method_10582("id", "minecraft:player");
        }
        
        final class_2487 finalPlayerNbt = playerNbt;
        final int finalSpawnX = spawnX;
        final int finalSpawnY = spawnY;
        final int finalSpawnZ = spawnZ;
        final String finalPlayerUuid = playerUuid;
        
        ModLogger.log("Pushing all loaded chunks into the save queue..."); 
        
        // Serialize all currently loaded chunks within view distance
        int viewDistance = client.field_1690.method_38521();
        class_1923 centerPos = client.field_1724.method_31476();
        String dimension = client.field_1687.method_27983().method_29177().method_12832();
        
        for (int x = -viewDistance; x <= viewDistance; x++) {
            for (int z = -viewDistance; z <= viewDistance; z++) {
                net.minecraft.class_2818 chunk = client.field_1687.method_2935().method_12126(centerPos.field_9181 + x, centerPos.field_9180 + z, false);
                if (chunk != null) {
                    queueChunkSave(dimension, chunk);
                }
            }
        }
        
        // Push level.dat save task
        saveQueue.add(() -> {
            saveLevelDat(finalPlayerNbt, finalSpawnX, finalSpawnY, finalSpawnZ, finalPlayerUuid);
            ModLogger.log("Map saving completed!");
            class_310.method_1551().execute(() -> {
                if (class_310.method_1551().field_1724 != null) {
                    class_310.method_1551().field_1724.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.command.save_success"), false);
                }
            });
        });
        
        // Force the save thread to run one more time if it's sleeping,
        // or recreate it if it died, to ensure the stop queue is flushed.
        startSaveThread();
    }

    public static boolean isRecording() {
        return isRecording;
    }

    public static boolean isSaving() {
        return !saveQueue.isEmpty();
    }

    public static void onChunkReceived(class_2818 chunk) {
        if (!isRecording) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;

        String dimension = client.field_1687.method_27983().method_29177().method_12832();
        
        // Filter out chunks outside the AutoScanner radius if it's active
        if (com.teoe.wdl.tracker.AutoScanner.isActive() && com.teoe.wdl.tracker.AutoScanner.startPos != null) {
            double distSq = (chunk.method_12004().method_8326() + 8 - com.teoe.wdl.tracker.AutoScanner.startPos.field_1352) * (chunk.method_12004().method_8326() + 8 - com.teoe.wdl.tracker.AutoScanner.startPos.field_1352) + 
                            (chunk.method_12004().method_8328() + 8 - com.teoe.wdl.tracker.AutoScanner.startPos.field_1350) * (chunk.method_12004().method_8328() + 8 - com.teoe.wdl.tracker.AutoScanner.startPos.field_1350);
            if (distSq > com.teoe.wdl.tracker.AutoScanner.scanRadius * com.teoe.wdl.tracker.AutoScanner.scanRadius) {
                return; // Discard chunks completely outside the radius
            }
        }


        
        // Record for AutoScanner
        for (net.minecraft.class_2586 be : chunk.method_12214().values()) {
            if (be instanceof net.minecraft.class_1263 || be instanceof net.minecraft.class_2621) {
                net.minecraft.class_2248 block = be.method_11010().method_26204();
                if (block == net.minecraft.class_2246.field_40276 ||
                    block == net.minecraft.class_2246.field_10223 ||
                    block == net.minecraft.class_2246.field_17350 ||
                    block == net.minecraft.class_2246.field_23860 ||
                    block == net.minecraft.class_2246.field_16330 ||
                    block == net.minecraft.class_2246.field_42752) {
                    continue; // Ignore blocks that don't have a normal chest GUI
                }
                discoveredChests.add(be.method_11016());
            }
        }

        // Queue an initial save just in case
        queueChunkSave(dimension, chunk);
    }

    public static void saveChunk(class_1923 pos) {
        if (!isRecording) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            net.minecraft.class_2818 chunk = client.field_1687.method_2935().method_12126(pos.field_9181, pos.field_9180, false);
            if (chunk != null) {
                com.teoe.wdl.server.MapGenerator.updateChunk(chunk);
                
                String dimension = client.field_1687.method_27983().method_29177().method_12832();
                queueChunkSave(dimension, chunk);
            }
        }
    }

    private static File getSaveDir() {
        class_310 client = class_310.method_1551();
        String serverName = "DownloadedServer";
        if (client.method_1558() != null) {
            serverName = client.method_1558().field_3761.replaceAll("[^a-zA-Z0-9.-]", "_");
        }
        return new File(client.field_1697, "wdl_saves/" + serverName + "_WDL");
    }

    private static void queueChunkSave(String dimension, class_2818 chunk) {
        if (cachedRegistryManager == null) return;
        com.teoe.wdl.server.MapGenerator.updateChunk(chunk);
        try {
            // Serialize on main thread to avoid ConcurrentModificationException
            class_310 client = class_310.method_1551();
            
            if (com.teoe.wdl.tracker.AutoScanner.scanNether && (dimension.equals("overworld") || dimension.equals("the_nether"))) {
                net.minecraft.class_2826[] sections = chunk.method_12006();
                for (int i = 0; i < sections.length; i++) {
                    net.minecraft.class_2826 section = sections[i];
                    if (!section.method_38292() && section.method_19523(state -> state.method_27852(net.minecraft.class_2246.field_10316))) {
                        int yOffset = chunk.method_31607() + (i * 16);
                        for (int x = 0; x < 16; x++) {
                            for (int y = 0; y < 16; y++) {
                                for (int z = 0; z < 16; z++) {
                                    if (section.method_12254(x, y, z).method_27852(net.minecraft.class_2246.field_10316)) {
                                        com.teoe.wdl.tracker.AutoScanner.netherPortals.add(chunk.method_12004().method_8323().method_10069(x, yOffset + y, z));
                                    }
                                }
                            }
                        }
                    }
                }
            }

            class_2487 nbt = RegionSaver.serializeClientChunk(client.field_1687, chunk, cachedRegistryManager);
            class_1923 pos = chunk.method_12004();
            File baseDirForEntities = getSaveDir();
            class_2487 entitiesNbt = EntitySaver.serializeEntities(client.field_1687, pos, baseDirForEntities, cachedRegistryManager);
            
            saveQueue.add(() -> {
                try {
                    File baseDir = getSaveDir();
                    File regionDir;
                    File entitiesDir;
                    if (dimension.equals("the_nether")) {
                        regionDir = new File(baseDir, "DIM-1/region");
                        entitiesDir = new File(baseDir, "DIM-1/entities");
                    } else if (dimension.equals("the_end")) {
                        regionDir = new File(baseDir, "DIM1/region");
                        entitiesDir = new File(baseDir, "DIM1/entities");
                    } else {
                        regionDir = new File(baseDir, "region");
                        entitiesDir = new File(baseDir, "entities");
                    }
                    regionDir.mkdirs();
                    entitiesDir.mkdirs();
                    RegionSaver.saveChunkToRegion(regionDir, pos, nbt);
                    if (entitiesNbt != null && entitiesNbt.method_10545("Entities") && !((net.minecraft.class_2499)entitiesNbt.method_10580("Entities")).isEmpty()) {
                        EntitySaver.saveEntitiesToRegion(entitiesDir, pos, entitiesNbt);
                    }
                    historicallySavedChunks.add(pos);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void saveLevelDat(class_2487 playerNbt, int spawnX, int spawnY, int spawnZ, String playerUuid) {
        File baseDir = getSaveDir();
        if (!baseDir.exists() && !baseDir.mkdirs()) {
            ModLogger.log("Failed to create save directory: " + baseDir.getAbsolutePath());
        }

        try {
            class_2487 root = new class_2487();
            class_2487 data = new class_2487();
            data.method_10582("LevelName", "Downloaded Server");
            data.method_10556("allowCommands", true);
            data.method_10569("version", 19133);
            
            class_2487 worldGenSettings = new class_2487();
            worldGenSettings.method_10544("seed", currentSeed);
            worldGenSettings.method_10556("generate_features", true);
            worldGenSettings.method_10556("bonus_chest", false);
            
            class_2487 dimensions = new class_2487();
            class_2487 overworld = new class_2487();
            class_2487 generator = new class_2487();
            generator.method_10582("type", "minecraft:noise");
            generator.method_10582("settings", "minecraft:overworld");
            
            class_2487 biomeSource = new class_2487();
            biomeSource.method_10582("type", "minecraft:multi_noise");
            biomeSource.method_10582("preset", "minecraft:overworld");
            generator.method_10566("biome_source", biomeSource);
            
            generator.method_10544("seed", currentSeed);
            overworld.method_10566("generator", generator);
            overworld.method_10582("type", "minecraft:overworld");
            
            dimensions.method_10566("minecraft:overworld", overworld);
            worldGenSettings.method_10566("dimensions", dimensions);
            
            data.method_10566("WorldGenSettings", worldGenSettings);
            
            data.method_10544("RandomSeed", currentSeed);
            if (playerNbt != null) {
                data.method_10569("SpawnX", spawnX);
                data.method_10569("SpawnY", spawnY);
                data.method_10569("SpawnZ", spawnZ);
                
                data.method_10566("Player", playerNbt);
                
                try {
                    File playerDataDir = new File(baseDir, "playerdata");
                    playerDataDir.mkdirs();
                    File playerFile = new File(playerDataDir, playerUuid + ".dat");
                    net.minecraft.class_2507.method_30614(playerNbt, playerFile.toPath());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            root.method_10566("Data", data);
            class_2507.method_30614(root, new File(baseDir, "level.dat").toPath());
        } catch (Exception e) {
            ModLogger.log("Failed to save level.dat: " + e.getMessage());
            e.printStackTrace();
        }
    }
}