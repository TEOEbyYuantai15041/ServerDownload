package com.teoe.wdl.tracker;

import com.teoe.wdl.DownloadManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.Queue;

public class AutoScanner {
    public enum Phase {
        IDLE, CHUNKS, DROP, CHESTS, MANUAL_PROMPT, MANUAL_SCAN, RETURN, GOTO_PORTAL, WAIT_PORTAL
    }
    
    private static Phase currentPhase = Phase.IDLE;
    
    public static Phase getCurrentPhase() {
        return currentPhase;
    }
    
    private static final Queue<class_1923> chunkQueue = new LinkedList<>();
    private static class_1923 currentChunkTarget = null;
    
    public static boolean scanNether = false;
    public static String startingDimension = "";
    public static boolean saveChests = true;
    public static final List<class_2338> netherPortals = new ArrayList<>();
    public static class_2338 currentPortalTarget = null;
    
    private static final List<class_2338> chestList = new ArrayList<>();
    public static class_2338 currentChestTarget = null;
    private static List<class_2338> currentChestPath = null;
    private static int chestWaitTicks = 0;
    private static class_243 lastXzPos = null;
    private static int ticksStuckXz = 0;
    private static int recalcAttempts = 0;
    
    public static String ignoredPlayerPrefix = "";

    private static int ticksStuck = 0;
    private static class_243 lastPos = null;

    public static class_243 startPos = null;
    public static int scanRadius = 0;
    private static class_243 homeTarget = null;

    public static void init() {
        ClientSendMessageEvents.ALLOW_CHAT.register((message) -> {
            if (currentPhase == Phase.MANUAL_PROMPT) {
                if (message.equalsIgnoreCase("y")) {
                    currentPhase = Phase.MANUAL_SCAN;
                    class_310.method_1551().field_1724.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.manual_start"), false);
                    return false;
                } else if (message.equalsIgnoreCase("n") || message.equalsIgnoreCase("stop")) {
                    currentPhase = Phase.RETURN;
                    homeTarget = startPos;
                    class_310.method_1551().field_1724.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.chests_done_returning"), false);
                    return false;
                }
            } else if (currentPhase == Phase.MANUAL_SCAN) {
                if (message.equalsIgnoreCase("stop")) {
                    currentPhase = Phase.RETURN;
                    homeTarget = startPos;
                    class_310.method_1551().field_1724.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.chests_done_returning"), false);
                    return false;
                }
            }
            return true;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (currentPhase == Phase.IDLE || !DownloadManager.isRecording() || client.field_1724 == null || client.field_1687 == null) {
                currentPhase = Phase.IDLE;
                return;
            }

            class_746 player = client.field_1724;
            
            boolean dropping = false;
            if (currentPhase == Phase.RETURN && homeTarget != null) {
                double dx = homeTarget.field_1352 - player.method_23317();
                double dz = homeTarget.field_1350 - player.method_23321();
                if (dx * dx + dz * dz < 25.0 && !player.field_5992) {
                    dropping = true;
                }
            } else if (currentPhase == Phase.DROP) {
                dropping = true;
            }

            // Critical NoFall fix:
            // The server calculates fall damage based on the Y-distance traveled since the last onGround=true.
            // If we send onGround=true while falling faster than 3.0 blocks/tick, the server calculates damage BEFORE resetting!
            // We MUST cap vertical velocity to -2.5 so the tick-by-tick fall distance never exceeds the 3.0 damage threshold.
            if (player.method_18798().field_1351 < -2.5) {
                player.method_18800(player.method_18798().field_1352, -2.5, player.method_18798().field_1350);
            }

            if (!dropping) {
                player.method_31549().field_7479 = true;
                player.field_6017 = 0.0f; 
                if (player.method_18798().field_1351 < 0) {
                    client.method_1562().method_52787(new net.minecraft.class_2828.class_5911(true, player.field_5976));
                }
            } else {
                player.method_31549().field_7479 = false;
                player.field_6017 = 0.0f;
                // Send onGround every tick while dropping. Since velocity is capped at -2.5, server damage is always 0.
                client.method_1562().method_52787(new net.minecraft.class_2828.class_5911(true, player.field_5976));
            }

            if (currentPhase == Phase.RETURN) {
                handleReturningHome(client, player);
                return;
            }

            if (currentPhase == Phase.CHUNKS) {
                handleChunkScan(client, player);
                return;
            }

            if (currentPhase == Phase.DROP) {
                if ((player.field_5992 && player.method_18798().field_1351 >= -0.1) || player.method_5799() || player.method_5771()) {
                    player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.landing_success"), false);
                    if (com.teoe.wdl.ConfigManager.saveChests) {
                        currentPhase = Phase.CHESTS;
                        currentChestTarget = null;
                        currentChestPath = null;
                        ChestTracker.ignoredChests.clear();
                    } else {
                        currentPhase = Phase.RETURN;
                        homeTarget = startPos;
                    }
                } else {
                    player.method_18800(0, player.method_18798().field_1351, 0); // Drop straight down
                }
                return;
            }

            if (currentPhase == Phase.CHESTS) {
                handleChestScan(client, player);
                return;
            }

            if (currentPhase == Phase.MANUAL_PROMPT) {
                // Just wait for user input
                player.method_18800(0, player.method_18798().field_1351, 0); // Drop straight down
                return;
            }

            if (currentPhase == Phase.MANUAL_SCAN) {
                // Check if all ignored chests are saved now
                int remaining = 0;
                for (class_2338 pos : ChestTracker.ignoredChests) {
                    if (!ChestTracker.savedChests.contains(pos)) {
                        remaining++;
                    }
                }
                if (remaining == 0) {
                    currentPhase = Phase.RETURN;
                    homeTarget = startPos;
                    player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.chests_done_returning"), false);
                } else {
                    // ESP for remaining chests
                    for (class_2338 pos : ChestTracker.ignoredChests) {
                        if (!ChestTracker.savedChests.contains(pos)) {
                            if (client.field_1687.field_9229.method_43048(3) == 0) {
                                client.field_1713.method_3056(
                                    net.minecraft.class_2398.field_11211,
                                    pos.method_10263() + 0.5 + (client.field_1687.field_9229.method_43058() - 0.5),
                                    pos.method_10264() + 0.5 + (client.field_1687.field_9229.method_43058() - 0.5),
                                    pos.method_10260() + 0.5 + (client.field_1687.field_9229.method_43058() - 0.5),
                                    0, 0, 0
                                );
                            }
                        }
                    }
                }
                return;
            }

            if (currentPhase == Phase.GOTO_PORTAL) {
                handleGotoPortal(client, player);
                return;
            }

            if (currentPhase == Phase.WAIT_PORTAL) {
                handleWaitPortal(client, player);
                return;
            }
        });
    }

    private static void handleChunkScan(class_310 client, class_746 player) {

        if (currentChunkTarget == null) {
            while (!chunkQueue.isEmpty()) {
                class_1923 pos = chunkQueue.poll();
                if (!DownloadManager.historicallySavedChunks.contains(pos)) {
                    currentChunkTarget = pos;
                    ticksStuck = 0;
                    break;
                }
            }

            if (currentChunkTarget == null) {
                if (com.teoe.wdl.ConfigManager.saveChests) {
                    currentPhase = Phase.DROP;
                    class_310.method_1551().field_1724.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.scan_done_dropping"), false);
                } else {
                    currentPhase = Phase.RETURN;
                    homeTarget = startPos;
                    class_310.method_1551().field_1724.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.scan_done_returning"), false);
                }
                return;
            }
        }

        double targetX = currentChunkTarget.method_8326() + 8.0;
        double targetY = 500.0;
        double targetZ = currentChunkTarget.method_8328() + 8.0;

        class_243 targetVec = new class_243(targetX, targetY, targetZ);
        class_243 currentVec = player.method_19538();
        
        if (player.method_31476().equals(currentChunkTarget)) {
            currentChunkTarget = null;
            return;
        }

        class_243 diff = targetVec.method_1020(currentVec);
        class_243 dir = diff.method_1029();
        
        player.method_18799(dir.method_1021(3.0));

        if (lastPos != null && lastPos.method_1025(currentVec) < 0.1) {
            ticksStuck++;
            if (ticksStuck > 40) {
                currentChunkTarget = null;
                ticksStuck = 0;
            }
        } else {
            ticksStuck = 0;
        }
        lastPos = currentVec;
    }

    private static void handleChestScan(class_310 client, class_746 player) {

        if (currentChestTarget == null) {
            // Dynamically refresh chestList from discoveredChests
            chestList.clear();
            for (class_2338 pos : DownloadManager.discoveredChests) {
                if (!ChestTracker.savedChests.contains(pos) && !ChestTracker.ignoredChests.contains(pos)) {
                    // Check if chunk is ignored by the ChunkFilter stick
                    if (ChunkFilter.ignoredChunks.contains(new net.minecraft.class_1923(pos))) {
                        continue;
                    }

                    // Pre-filter chests that are physically impossible to open
                    net.minecraft.class_2680 upState = client.field_1687.method_8320(pos.method_10084());
                    if (upState.method_26212(client.field_1687, pos.method_10084())) {
                        ChestTracker.ignoredChests.add(pos);
                        continue;
                    }

                    double distSq = (pos.method_10263() - startPos.field_1352) * (pos.method_10263() - startPos.field_1352) + 
                                    (pos.method_10260() - startPos.field_1350) * (pos.method_10260() - startPos.field_1350);
                    if (distSq <= scanRadius * scanRadius) {
                        chestList.add(pos);
                    }
                }
            }
            
            if (chestList.isEmpty()) {
                int remaining = 0;
                for (class_2338 pos : ChestTracker.ignoredChests) {
                    if (!ChestTracker.savedChests.contains(pos)) remaining++;
                }
                
                if (remaining > 0) {
                    currentPhase = Phase.MANUAL_PROMPT;
                    player.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.scanner.manual_prompt", remaining), false);
                } else {
                    currentPhase = Phase.RETURN;
                    homeTarget = startPos;
                    player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.chests_done_returning"), false);
                }
                return;
            }

            // Find nearest chest dynamically
            class_243 playerPos = player.method_19538();
            class_2338 nearest = null;
            double minDist = Double.MAX_VALUE;
            
            for (class_2338 pos : chestList) {
                double dist = pos.method_19770(playerPos);
                if (dist < minDist) {
                    minDist = dist;
                    nearest = pos;
                }
            }
            
            currentChestTarget = nearest;
            chestList.remove(nearest);
            chestWaitTicks = 0;
            ticksStuck = 0;
            ticksStuckXz = 0;
            lastXzPos = null;
            recalcAttempts = 0;
            currentChestPath = null;
            
            // Check if we can already reach the chest directly BEFORE pathfinding!
            class_243 chestVec = class_243.method_24953(currentChestTarget);
            double distSq = player.method_19538().method_1025(chestVec);
            boolean inRange = false;
            
            if (distSq < 18.0) { // Max potential reach 4.2 blocks
                net.minecraft.class_239 result = client.field_1687.method_17742(new net.minecraft.class_3959(
                    player.method_5836(1.0F), chestVec,
                    net.minecraft.class_3959.class_3960.field_17558,
                    net.minecraft.class_3959.class_242.field_1348, player
                ));
                
                boolean hasLineOfSight = (result.method_17783() == net.minecraft.class_239.class_240.field_1333 || 
                   (result.method_17783() == net.minecraft.class_239.class_240.field_1332 && ((net.minecraft.class_3965)result).method_17777().equals(currentChestTarget)));
                   
                if (hasLineOfSight) {
                    inRange = true; // Clear line of sight, 4.2 reach is fine
                } else if (distSq < 7.0) { // ~2.6 blocks max for through-wall interactions to prevent false positives
                    inRange = true; // Blocked, but close enough to punch through the wall
                }
            }
            
            if (inRange) {
                // We can reach it! Just stop and let ChestAura do the work.
                player.method_18800(0, 0, 0);
                chestWaitTicks++;
                if (chestWaitTicks > 100) { // 5 seconds timeout
                    ChestTracker.ignoredChests.add(currentChestTarget);
                    currentChestTarget = null;
                }
                return;
            }

            // Attempt to find path to chest synchronously (max 5000 nodes, ~1-2ms)
            // findPath will now return the CLOSEST possible path even if it fails to reach the target exactly
            currentChestPath = PathFinder.findPath(client.field_1687, player.method_24515(), currentChestTarget, 30000);
            if (currentChestPath == null || currentChestPath.isEmpty()) {
                ChestTracker.ignoredChests.add(currentChestTarget);
                // player.sendMessage(net.minecraft.text.Text.translatable("teoe.wdl.scanner.path_fail_buried", currentChestTarget.toShortString()), false);
                currentChestTarget = null;
            }
            return;
        }

        // Check for nearby players to evade detection
        boolean playerNear = false;
        for (class_1657 p : client.field_1687.method_18456()) {
            if (p != player && p.method_5707(class_243.method_24953(currentChestTarget)) < 2500.0) { // Within 50 blocks
                if (!com.teoe.wdl.ConfigManager.botPrefix.isEmpty() && p.method_5477().getString().startsWith(com.teoe.wdl.ConfigManager.botPrefix)) {
                    continue; // Ignore bots
                }
                playerNear = true;
                break;
            }
        }

        if (playerNear) {
            ChestTracker.ignoredChests.add(currentChestTarget);
            player.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.scanner.player_nearby", currentChestTarget.method_23854()), false);
            currentChestTarget = null;
            return;
        }

        // Check if ChestAura has already processed it
        if (ChestTracker.savedChests.contains(currentChestTarget) || ChestTracker.ignoredChests.contains(currentChestTarget)) {
            currentChestTarget = null;
            return;
        }

        // If ChestAura is currently working on it, just hover and wait
            if (ChestAura.currentTarget != null && ChestAura.currentTarget.equals(currentChestTarget)) {
                player.method_18800(0, 0, 0);
                return;
            }

            // Check if we can already reach the chest directly! If so, wait for ChestAura
            if (currentChestPath == null || currentChestPath.isEmpty()) {
                class_243 chestVec = class_243.method_24953(currentChestTarget);
                double distSq = player.method_19538().method_1025(chestVec);
                boolean inRange = false;
                
                if (distSq < 18.0) { // Max potential reach 4.2 blocks
                    net.minecraft.class_239 result = client.field_1687.method_17742(new net.minecraft.class_3959(
                        player.method_5836(1.0F), chestVec,
                        net.minecraft.class_3959.class_3960.field_17558,
                        net.minecraft.class_3959.class_242.field_1348, player
                    ));
                    
                    boolean hasLineOfSight = (result.method_17783() == net.minecraft.class_239.class_240.field_1333 || 
                       (result.method_17783() == net.minecraft.class_239.class_240.field_1332 && ((net.minecraft.class_3965)result).method_17777().equals(currentChestTarget)));
                       
                    if (hasLineOfSight) {
                        inRange = true; // Clear line of sight, 4.2 reach is fine
                    } else if (distSq < 7.0) { // ~2.6 blocks max for through-wall interactions
                        inRange = true; // Blocked, but close enough to punch through the wall
                    }
                }
                
                if (inRange) {
                    // Reached it! Stop and let ChestAura open it
                    player.method_18800(0, 0, 0);
                    chestWaitTicks++;
                    if (chestWaitTicks > 100) { // 5 seconds timeout
                        ChestTracker.ignoredChests.add(currentChestTarget);
                        player.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.scanner.open_timeout", currentChestTarget.method_23854()), false);
                        currentChestTarget = null;
                    }
                    return;
                } 
                
                // Drifted off or path ended prematurely. Recalculate!
                currentChestPath = PathFinder.findPath(client.field_1687, player.method_24515(), currentChestTarget, 30000);
                if (currentChestPath == null || currentChestPath.isEmpty()) {
                    ChestTracker.ignoredChests.add(currentChestTarget);
                    // player.sendMessage(net.minecraft.text.Text.translatable("teoe.wdl.scanner.path_fail", currentChestTarget.toShortString()), false);
                    currentChestTarget = null;
                    return;
                }
            } else {
                chestWaitTicks = 0; // Reset wait ticks while walking
            }

            // Follow path
            if (currentChestPath != null && !currentChestPath.isEmpty()) {
            class_2338 nextNode = currentChestPath.get(0);
            
            // Preemptively open closed doors/gates in the next node to prevent getting stuck
            boolean doorBlocking = false;
            class_2338 cp = player.method_24515();
            for (class_2338 p : new class_2338[]{nextNode.method_10074(), nextNode, nextNode.method_10084(), cp.method_10074(), cp, cp.method_10084()}) {
                net.minecraft.class_2680 state = client.field_1687.method_8320(p);
                net.minecraft.class_2248 block = state.method_26204();
                if (block instanceof net.minecraft.class_2323 || 
                    block instanceof net.minecraft.class_2533 || 
                    block instanceof net.minecraft.class_2349) {
                    if (state.method_28498(net.minecraft.class_2741.field_12537) && !state.method_11654(net.minecraft.class_2741.field_12537)) {
                        if (tryOpenDoor(client, player, p, state)) {
                            doorBlocking = true;
                        }
                    }
                } else if (p.equals(nextNode.method_10084()) && !state.method_26220(client.field_1687, p).method_1110()) {
                    // Try to break blocks that are in our head space and causing pathfinding failure
                    // This handles cases where trapdoors or other blocks are in our way but not registered as doors
                    doorBlocking = true;
                }
            }

            if (doorBlocking) {
                player.method_18800(0, 0, 0);
                return; // Wait for door to open!
            }

            class_243 targetVec = new class_243(nextNode.method_10263() + 0.5, nextNode.method_10264(), nextNode.method_10260() + 0.5); // Target feet to floor to trigger pressure plates
            
            boolean needsSneak = false;
            class_2338 currentPos = player.method_24515();
            
            // Check clearance for current pos
            net.minecraft.class_2680 currentDownState = client.field_1687.method_8320(currentPos.method_10074());
            double currentFloorY = 0;
            if (!currentDownState.method_26220(client.field_1687, currentPos.method_10074()).method_1110()) {
                currentFloorY = currentDownState.method_26220(client.field_1687, currentPos.method_10074()).method_1105(net.minecraft.class_2350.class_2351.field_11052) - 1.0;
                if (currentFloorY < 0) currentFloorY = 0;
            }
            
            net.minecraft.class_2680 currentUpState = client.field_1687.method_8320(currentPos.method_10086(2));
            double currentCeilY = 2.0;
            if (!currentUpState.method_26220(client.field_1687, currentPos.method_10086(2)).method_1110()) {
                double minUp = currentUpState.method_26220(client.field_1687, currentPos.method_10086(2)).method_1091(net.minecraft.class_2350.class_2351.field_11052);
                if (!Double.isInfinite(minUp) && !Double.isNaN(minUp)) {
                    currentCeilY = 2.0 + minUp;
                }
            }
            net.minecraft.class_2680 currentPosUpState = client.field_1687.method_8320(currentPos.method_10084());
            if (!currentPosUpState.method_26220(client.field_1687, currentPos.method_10084()).method_1110()) {
                double minUp = currentPosUpState.method_26220(client.field_1687, currentPos.method_10084()).method_1091(net.minecraft.class_2350.class_2351.field_11052);
                if (!Double.isInfinite(minUp) && !Double.isNaN(minUp)) {
                    currentCeilY = Math.min(currentCeilY, 1.0 + minUp);
                }
            }
            
            if (currentCeilY - currentFloorY < 1.8) {
                needsSneak = true;
            }

            net.minecraft.class_2680 downState = client.field_1687.method_8320(nextNode.method_10074());
            double nextFloorY = 0;
            if (!downState.method_26220(client.field_1687, nextNode.method_10074()).method_1110()) {
                double downMaxY = downState.method_26220(client.field_1687, nextNode.method_10074()).method_1105(net.minecraft.class_2350.class_2351.field_11052);
                targetVec = new class_243(targetVec.field_1352, nextNode.method_10264() - 1 + downMaxY, targetVec.field_1350);
                nextFloorY = downMaxY - 1.0;
                if (nextFloorY < 0) nextFloorY = 0;
            }
            
            net.minecraft.class_2680 nextUpState = client.field_1687.method_8320(nextNode.method_10086(2));
            double nextCeilY = 2.0;
            if (!nextUpState.method_26220(client.field_1687, nextNode.method_10086(2)).method_1110()) {
                double minUp = nextUpState.method_26220(client.field_1687, nextNode.method_10086(2)).method_1091(net.minecraft.class_2350.class_2351.field_11052);
                if (!Double.isInfinite(minUp) && !Double.isNaN(minUp)) {
                    nextCeilY = 2.0 + minUp;
                }
            }
            net.minecraft.class_2680 posUpState = client.field_1687.method_8320(nextNode.method_10084());
            if (!posUpState.method_26220(client.field_1687, nextNode.method_10084()).method_1110()) {
                double minUp = posUpState.method_26220(client.field_1687, nextNode.method_10084()).method_1091(net.minecraft.class_2350.class_2351.field_11052);
                if (!Double.isInfinite(minUp) && !Double.isNaN(minUp)) {
                    nextCeilY = Math.min(nextCeilY, 1.0 + minUp);
                }
            }
            
            if (nextCeilY - nextFloorY < 1.8) {
                needsSneak = true;
            }
            
            client.field_1690.field_1832.method_23481(needsSneak);
            player.method_5660(needsSneak); // Force pose update instantly

            class_243 currentVec = player.method_19538();

            if (currentVec.method_1025(targetVec) < 0.6) { // Reached node
                currentChestPath.remove(0);
                ticksStuck = 0;
                ticksStuckXz = 0;
                client.field_1690.field_1832.method_23481(false);
                if (currentChestPath.isEmpty()) {
                    currentChestPath = null;
                }
                return;
            }
            
            class_243 diff = targetVec.method_1020(currentVec);
            
            // Fast Anti-Stuck (0.05 dist). Put this BEFORE velocity calculation so we can override it!
            if (lastPos != null && lastPos.method_1025(currentVec) < 0.05) {
                ticksStuck++;
            } else {
                ticksStuck = 0;
            }

            // Anti-stuck XZ (5 seconds)
            class_243 currentXz = new class_243(currentVec.field_1352, 0, currentVec.field_1350);
            if (lastXzPos != null && lastXzPos.method_1025(currentXz) < 0.1) {
                ticksStuckXz++;
                if (ticksStuckXz > 100) { // 5 seconds
                    if (recalcAttempts < 3) {
                        currentChestPath = null;
                        ticksStuckXz = 0;
                        recalcAttempts++;
                        player.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.scanner.stuck_recalc", recalcAttempts), false);
                    } else {
                        ChestTracker.ignoredChests.add(currentChestTarget);
                        player.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.scanner.stuck_skip", currentChestTarget.method_23854()), false);
                        currentChestTarget = null;
                    }
                }
            } else {
                ticksStuckXz = 0;
                recalcAttempts = 0;
            }
            lastXzPos = currentXz;
            
            // Move towards next node
            double speed = Math.min(1.2, diff.method_1033()); // Increased speed to 1.2
            class_243 moveDir = diff.method_1029().method_1021(speed); 
            
            if (ticksStuck > 10) {
                // We are stuck! Override the normal movement and boost UP and FORWARD to clear the obstacle
                if (currentCeilY - currentFloorY > 2.0) {
                    player.method_18800(moveDir.field_1352, 0.4, moveDir.field_1350); // Push up and keep pushing forward
                } else {
                    player.method_18800(moveDir.field_1352, 0, moveDir.field_1350); // No space to push up
                }
            } else if (diff.field_1351 > 0.2) {
                // Need to ascend! Prioritize vertical movement to clear block edges horizontally
                player.method_18800(moveDir.field_1352 * 0.4, Math.min(0.6, diff.field_1351 * 2.0), moveDir.field_1350 * 0.4);
            } else {
                // Normal flying. IMPORTANT: When flying is true, player ignores gravity. We MUST set downward velocity manually.
                player.method_18800(moveDir.field_1352, moveDir.field_1351, moveDir.field_1350);
            }
        }
        lastPos = player.method_19538();
    }

    private static void handleReturningHome(class_310 client, class_746 player) {
        if (homeTarget == null) {
            stopScanning();
            return;
        }

        boolean safe = false;
        int attempts = 0;
        
        while (!safe && attempts < 100) {
            safe = true;
            for (net.minecraft.class_1657 p : client.field_1687.method_18456()) {
                if (p != player && p.method_5707(homeTarget) < 10000.0) { // Within 100 blocks
                    if (!com.teoe.wdl.ConfigManager.botPrefix.isEmpty() && p.method_5477().getString().startsWith(com.teoe.wdl.ConfigManager.botPrefix)) {
                        continue; // Ignore bots
                    }
                    safe = false;
                    double angle = Math.random() * Math.PI * 2;
                    homeTarget = homeTarget.method_1031(Math.cos(angle) * 300, 0, Math.sin(angle) * 300); // Offset by 300 blocks
                    player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.player_offset"), false);
                    break;
                }
            }
            attempts++;
        }

        class_243 currentVec = player.method_19538();
        
        double dx = homeTarget.field_1352 - currentVec.field_1352;
        double dz = homeTarget.field_1350 - currentVec.field_1350;
        double dy = homeTarget.field_1351 - currentVec.field_1351;
        
        // Arrived at home position horizontally, now descend
        if (dx * dx + dz * dz < 25.0) { // Within 5 blocks horizontally
            if ((player.field_5992 && player.method_18798().field_1351 >= -0.1) || player.method_5799() || player.method_5771()) {
                // Arrived completely
                String dim = client.field_1687.method_27983().method_29177().method_12832();
                if (com.teoe.wdl.ConfigManager.scanNether && (dim.equals("overworld") || dim.equals("the_nether")) && !netherPortals.isEmpty()) {
                    currentPhase = Phase.GOTO_PORTAL;
                    currentPortalTarget = null;
                    if (dim.equals("overworld")) {
                        player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.overworld_done_nether"), false);
                    } else {
                        player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.nether_done_overworld"), false);
                    }
                } else {
                    stopScanning();
                    player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.all_done"), false);
                }
                return;
            } else {
                // Disable horizontal drift, let gravity handle the drop
                player.method_18800(0, player.method_18798().field_1351, 0); 
            }
        } else {
            // Fly towards home at a safe altitude
            double targetY = 315.0;
            double flyDy = targetY - currentVec.field_1351;
            
            if (currentVec.field_1351 < 300.0) {
                // Need to ascend. If we hit something (like a ceiling), try to drift outwards
                if (player.field_5992) {
                    player.method_18799(new class_243(dx, 0, dz).method_1029().method_1021(1.5));
                } else if (player.field_5976) {
                    player.method_18799(new class_243(-dz, 2.0, dx).method_1029().method_1021(1.5));
                } else {
                    player.method_18800(0, 2.0, 0); // Ascend straight up first
                }
            } else {
                // Safe altitude reached, cruise horizontally
                player.method_18799(new class_243(dx, 0, dz).method_1029().method_1021(2.0));
            }
        }
    }

    private static void handleGotoPortal(class_310 client, class_746 player) {
        if (currentPortalTarget == null) {
            double minDist = Double.MAX_VALUE;
            for (class_2338 p : netherPortals) {
                double d = p.method_19770(player.method_19538());
                if (d < minDist) { minDist = d; currentPortalTarget = p; }
            }
            if (currentPortalTarget == null) {
                stopScanning();
                return;
            }
            currentChestPath = null;
        }

        double distSq = player.method_19538().method_1025(class_243.method_24953(currentPortalTarget));
        if (distSq < 4.0) {
            currentPhase = Phase.WAIT_PORTAL;
            player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.waiting_portal"), false);
            return;
        }

        // If close enough, use PathFinder
        if (distSq < 2500.0) { // 50 blocks
            if (currentChestPath == null || currentChestPath.isEmpty()) {
                currentChestPath = PathFinder.findPath(client.field_1687, player.method_24515(), currentPortalTarget, 5000);
                if (currentChestPath == null || currentChestPath.isEmpty()) {
                    netherPortals.remove(currentPortalTarget);
                    currentPortalTarget = null;
                    return; // Try next portal
                }
            }
            // Follow path
            class_2338 nextNode = currentChestPath.get(0);

            // Preemptively open closed doors/gates
            boolean doorBlocking = false;
            class_2338 cp = player.method_24515();
            for (class_2338 p : new class_2338[]{nextNode.method_10074(), nextNode, nextNode.method_10084(), cp.method_10074(), cp, cp.method_10084()}) {
                net.minecraft.class_2680 state = client.field_1687.method_8320(p);
                net.minecraft.class_2248 block = state.method_26204();
                if (block instanceof net.minecraft.class_2323 || 
                    block instanceof net.minecraft.class_2533 || 
                    block instanceof net.minecraft.class_2349) {
                    if (state.method_28498(net.minecraft.class_2741.field_12537) && !state.method_11654(net.minecraft.class_2741.field_12537)) {
                        if (tryOpenDoor(client, player, p, state)) {
                            doorBlocking = true;
                        }
                    }
                }
            }

            if (doorBlocking) {
                player.method_18800(0, 0, 0);
                return; // Wait for door to open!
            }

            class_243 targetVec = new class_243(nextNode.method_10263() + 0.5, nextNode.method_10264(), nextNode.method_10260() + 0.5); // Target feet to floor to trigger pressure plates
            net.minecraft.class_2680 downState = client.field_1687.method_8320(nextNode.method_10074());
            boolean needsSneak = false;
            if (!downState.method_26220(client.field_1687, nextNode.method_10074()).method_1110()) {
                double downMaxY = downState.method_26220(client.field_1687, nextNode.method_10074()).method_1105(net.minecraft.class_2350.class_2351.field_11052);
                targetVec = new class_243(targetVec.field_1352, nextNode.method_10264() - 1 + downMaxY, targetVec.field_1350);
                
                if (downMaxY > 1.0) {
                    class_2338 blockAbove = nextNode.method_10086(2);
                    net.minecraft.class_2680 upState = client.field_1687.method_8320(blockAbove);
                    if (!upState.method_26220(client.field_1687, blockAbove).method_1110()) {
                        double minUpY = upState.method_26220(client.field_1687, blockAbove).method_1091(net.minecraft.class_2350.class_2351.field_11052);
                        if (!Double.isInfinite(minUpY) && !Double.isNaN(minUpY)) {
                            double clearance = (2.0 + minUpY) - downMaxY;
                            if (clearance < 1.8) {
                                needsSneak = true;
                            }
                        }
                    }
                }
            }
            client.field_1690.field_1832.method_23481(needsSneak);

            if (player.method_19538().method_1025(targetVec) < 0.6) {
                currentChestPath.remove(0);
                ticksStuck = 0;
                client.field_1690.field_1832.method_23481(false);
                if (currentChestPath.isEmpty()) return;
                nextNode = currentChestPath.get(0);
                targetVec = new class_243(nextNode.method_10263() + 0.5, nextNode.method_10264(), nextNode.method_10260() + 0.5);
                downState = client.field_1687.method_8320(nextNode.method_10074());
                if (!downState.method_26220(client.field_1687, nextNode.method_10074()).method_1110()) {
                    double downMaxY = downState.method_26220(client.field_1687, nextNode.method_10074()).method_1105(net.minecraft.class_2350.class_2351.field_11052);
                    targetVec = new class_243(targetVec.field_1352, nextNode.method_10264() - 1 + downMaxY, targetVec.field_1350);
                }
            }
            
            class_243 diff = targetVec.method_1020(player.method_19538());
            if (diff.field_1351 > 0.1) {
                diff = diff.method_1031(0, 0.3, 0);
            }
            
            if (lastPos != null && lastPos.method_1025(player.method_19538()) < 0.05) {
                ticksStuck++;
                if (ticksStuck > 10) {
                    player.method_18800(0, 0.6, 0);
                    if (ticksStuck > 30) {
                        currentChestPath = null;
                        ticksStuck = 0;
                    }
                } else {
                    player.method_18799(diff.method_1029().method_1021(0.6));
                }
            } else {
                ticksStuck = 0;
                player.method_18799(diff.method_1029().method_1021(0.6));
            }
            lastPos = player.method_19538();
        } else {
            // Fly high and move towards X/Z
            double targetX = currentPortalTarget.method_10263() + 0.5;
            double targetZ = currentPortalTarget.method_10260() + 0.5;
            double targetY = 150.0; // safe height

            double dx = targetX - player.method_23317();
            double dz = targetZ - player.method_23321();
            
            if (dx * dx + dz * dz < 25.0) {
                // Above portal, descend
                targetY = currentPortalTarget.method_10264() + 2.0; 
            }

            class_243 targetVec = new class_243(targetX, targetY, targetZ);
            class_243 currentVec = player.method_19538();
            class_243 diff = targetVec.method_1020(currentVec);

            // Anti-stuck
            if (lastPos != null && lastPos.method_1025(currentVec) < 0.01) {
                ticksStuck++;
                if (ticksStuck > 10) {
                    player.method_18800(0, 1.0, 0); // Fly up
                } else {
                    player.method_18799(diff.method_1029().method_1021(1.5));
                }
            } else {
                ticksStuck = 0;
                player.method_18799(diff.method_1029().method_1021(1.5));
            }
            lastPos = currentVec;
        }
    }

    private static void handleWaitPortal(class_310 client, class_746 player) {
        String currentDim = client.field_1687.method_27983().method_29177().method_12832();
        if (!currentDim.equals(startingDimension)) {
            scanNether = false; // Prevent loop
            netherPortals.clear();
            com.teoe.wdl.DownloadManager.historicallySavedChunks.clear();
            com.teoe.wdl.server.MapGenerator.clear();
            startScanning(scanRadius * 2);
            if (currentDim.equals("the_nether")) {
                player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.enter_nether"), false);
            } else if (currentDim.equals("overworld")) {
                player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.enter_overworld"), false);
            } else {
                player.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.enter_dimension"), false);
            }
            return;
        }
        
        // Keep player in the portal to trigger teleport
        class_243 targetVec = class_243.method_24953(currentPortalTarget);
        player.method_5814(targetVec.field_1352, targetVec.field_1351, targetVec.field_1350);
        player.method_18800(0, 0, 0);
    }

    public static void startScanning(int diameter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        
        if (currentPhase == Phase.IDLE) {
            startingDimension = client.field_1687.method_27983().method_29177().method_12832();
        }

        com.teoe.wdl.ConfigManager.diameter = diameter;
        com.teoe.wdl.ConfigManager.save();

        chunkQueue.clear();
        chestList.clear();
        currentChunkTarget = null;
        currentChestTarget = null;
        currentPhase = Phase.CHUNKS;
        startPos = client.field_1724.method_19538();
        scanRadius = diameter / 2;

        class_1923 startChunk = client.field_1724.method_31476();
        int chunkRadius = scanRadius / 16;

        // Generate spiral chunk coordinates
        int x = 0;
        int z = 0;
        int dx = 0;
        int dz = -1;
        int t = Math.max(chunkRadius * 2 + 1, chunkRadius * 2 + 1);
        int maxI = t * t;

        for (int i = 0; i < maxI; i++) {
            if (-chunkRadius <= x && x <= chunkRadius && -chunkRadius <= z && z <= chunkRadius) {
                class_1923 pos = new class_1923(startChunk.field_9181 + x, startChunk.field_9180 + z);
                
                // Only add if the chunk is strictly within the radius distance (circular bounding)
                double distSq = (pos.method_8326() + 8 - startPos.field_1352) * (pos.method_8326() + 8 - startPos.field_1352) + 
                                (pos.method_8328() + 8 - startPos.field_1350) * (pos.method_8328() + 8 - startPos.field_1350);
                
                if (distSq <= scanRadius * scanRadius && !DownloadManager.historicallySavedChunks.contains(pos)) {
                    chunkQueue.add(pos);
                }
            }
            if (x == z || (x < 0 && x == -z) || (x > 0 && x == 1 - z)) {
                t = dx;
                dx = -dz;
                dz = t;
            }
            x += dx;
            z += dz;
        }

        client.field_1724.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.scanner.started", diameter, chunkQueue.size()), false);
        ChunkFilter.materializeVirtualBlocks(true);
    }

    public static void stopScanning() {
        currentPhase = Phase.IDLE;
        chunkQueue.clear();
        chestList.clear();
        currentChunkTarget = null;
        currentChestTarget = null;
        currentPortalTarget = null;
        ChunkFilter.materializeVirtualBlocks(false);
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_31549().field_7479 = false;
            client.field_1690.field_1832.method_23481(false);
            client.field_1724.method_7353(net.minecraft.class_2561.method_43471("teoe.wdl.scanner.stopped"), false);
        }
        com.teoe.wdl.DownloadManager.stopRecording();
    }

    public static boolean isActive() {
        return currentPhase != Phase.IDLE;
    }
    
    public static int getRemainingChunks() {
        if (currentPhase == Phase.CHUNKS) {
            return chunkQueue.size() + (currentChunkTarget != null ? 1 : 0);
        } else if (currentPhase == Phase.CHESTS) {
            return chestList.size() + (currentChestTarget != null ? 1 : 0);
        }
        return 0;
    }

    public static String getPhaseName() {
        return currentPhase.name();
    }

    public static List<class_2338> getCurrentChestPath() {
        return currentChestPath;
    }

    private static boolean tryOpenDoor(class_310 client, class_746 player, class_2338 p, net.minecraft.class_2680 state) {
        net.minecraft.class_2248 block = state.method_26204();
        if (block instanceof net.minecraft.class_2323 || 
            block instanceof net.minecraft.class_2533 || 
            block instanceof net.minecraft.class_2349) {
            if (state.method_28498(net.minecraft.class_2741.field_12537) && !state.method_11654(net.minecraft.class_2741.field_12537)) {
                if (block == net.minecraft.class_2246.field_9973 || block == net.minecraft.class_2246.field_10453) {
                    // Search for nearby button or lever around the player
                    boolean found = false;
                    class_2338 playerPos = player.method_24515();
                    for (int dx = -2; dx <= 2; dx++) {
                        for (int dy = -1; dy <= 2; dy++) {
                            for (int dz = -2; dz <= 2; dz++) {
                                class_2338 searchPos = playerPos.method_10069(dx, dy, dz);
                                net.minecraft.class_2680 searchState = client.field_1687.method_8320(searchPos);
                                net.minecraft.class_2248 searchBlock = searchState.method_26204();
                                if (searchBlock instanceof net.minecraft.class_2269 || searchBlock instanceof net.minecraft.class_2401) {
                                    // Don't click already powered buttons/levers to avoid spamming
                                    if (searchState.method_28498(net.minecraft.class_2741.field_12484) && searchState.method_11654(net.minecraft.class_2741.field_12484)) {
                                        continue;
                                    }
                                    client.field_1761.method_2896(player, net.minecraft.class_1268.field_5808, new net.minecraft.class_3965(class_243.method_24953(searchPos), net.minecraft.class_2350.field_11036, searchPos, false));
                                    client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
                                    found = true;
                                    break;
                                }
                            }
                            if (found) break;
                        }
                        if (found) break;
                    }
                    return found;
                } else {
                    client.field_1761.method_2896(player, net.minecraft.class_1268.field_5808, new net.minecraft.class_3965(class_243.method_24953(p), net.minecraft.class_2350.field_11036, p, false));
                    client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
                    return true;
                }
            }
        }
        return false;
    }
}