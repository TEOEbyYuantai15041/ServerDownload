package com.teoe.wdl.tracker;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_1923;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.Set;

public class ChunkFilter {
    public static final Set<class_1923> ignoredChunks = new HashSet<>();
    private static boolean wasHoldingIgnoreStick = false;
    private static boolean previousChunkBorderState = false;
    private static boolean wasAttackPressed = false;

    public static final java.util.Set<net.minecraft.class_2338> virtualBlocks = new java.util.HashSet<>();
    
    public static void materializeVirtualBlocks(boolean materialize) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;
        for (net.minecraft.class_2338 pos : virtualBlocks) {
            if (materialize) {
                client.field_1687.method_8652(pos, net.minecraft.class_2246.field_10272.method_9564(), 3);
            } else {
                client.field_1687.method_8652(pos, net.minecraft.class_2246.field_10124.method_9564(), 3);
            }
        }
    }
    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            
            class_1799 stack = client.field_1724.method_6047();
            boolean isHoldingIgnoreStick = stack.method_31574(class_1802.field_8600) && stack.method_57826(net.minecraft.class_9334.field_49631) && stack.method_7964().getString().equals("ignore");
            
            if (isHoldingIgnoreStick) {
                boolean isAttackPressed = client.field_1690.field_1886.method_1434();
                if (isAttackPressed && !wasAttackPressed) {
                    VHit hit = customRaycast(client.field_1724, 5.0);
                    if (hit != null) {
                        if (client.field_1724.method_5715()) {
                            if (hit.isVirtual) {
                                virtualBlocks.remove(hit.pos);
                                client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§cRemoved virtual block"), true);
                            }
                        } else {
                            net.minecraft.class_2338 newPos = hit.isVirtual ? hit.pos.method_10093(hit.side) : hit.pos.method_10093(hit.side);
                            virtualBlocks.add(newPos);
                            client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§aAdded virtual block"), true);
                        }
                    }
                }
                wasAttackPressed = isAttackPressed;
            } else {
                wasAttackPressed = false;
            }
            
            if (isHoldingIgnoreStick && !wasHoldingIgnoreStick) {
                // Just started holding
                boolean newState = client.field_1709.method_3713();
                previousChunkBorderState = !newState; // It was the opposite of the new state
                if (!newState) {
                    client.field_1709.method_3713(); // If it turned off, turn it back on
                }
                wasHoldingIgnoreStick = true;
            } else if (!isHoldingIgnoreStick && wasHoldingIgnoreStick) {
                // Stopped holding
                if (!previousChunkBorderState) {
                    client.field_1709.method_3713(); // Turn it off if it was off before
                }
                wasHoldingIgnoreStick = false;
            }
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.field_9236 && hand == net.minecraft.class_1268.field_5808) {
                class_1799 stack = player.method_5998(hand);
                if (stack.method_31574(class_1802.field_8600) && stack.method_57826(net.minecraft.class_9334.field_49631) && stack.method_7964().getString().equals("ignore")) {
                    class_1923 pos = new class_1923(hitResult.method_17777());
                    if (ignoredChunks.contains(pos)) {
                        ignoredChunks.remove(pos);
                        player.method_7353(net.minecraft.class_2561.method_43470("§aRemoved chunk from ignore list: " + pos), true);
                    } else {
                        ignoredChunks.add(pos);
                        player.method_7353(net.minecraft.class_2561.method_43470("§cAdded chunk to ignore list: " + pos), true);
                    }
                    return class_1269.field_5812; // Cancel block interaction
                }
            }
            return class_1269.field_5811;
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.field_9236 && hand == net.minecraft.class_1268.field_5808) {
                class_1799 stack = player.method_5998(hand);
                if (stack.method_31574(class_1802.field_8600) && stack.method_57826(net.minecraft.class_9334.field_49631) && stack.method_7964().getString().equals("ignore")) {
                    return class_1269.field_5812; // Cancel block breaking when holding the ignore stick
                }
            }
            return class_1269.field_5811;
        });

        WorldRenderEvents.LAST.register(context -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || ignoredChunks.isEmpty()) return;

            class_1799 stack = client.field_1724.method_6047();
            if (!(stack.method_31574(class_1802.field_8600) && stack.method_57826(net.minecraft.class_9334.field_49631) && stack.method_7964().getString().equals("ignore"))) {
                return; // Only render when holding the stick
            }

            class_4587 matrices = context.matrixStack();
            class_243 cameraPos = context.camera().method_19326();
            class_4588 vertexConsumer = context.consumers().getBuffer(class_1921.method_49043(2.0));

            for (class_1923 pos : ignoredChunks) {
                // Render a blue box around the chunk
                double minX = pos.method_8326() - cameraPos.field_1352;
                double minZ = pos.method_8328() - cameraPos.field_1350;
                double maxX = pos.method_8327() + 1 - cameraPos.field_1352;
                double maxZ = pos.method_8329() + 1 - cameraPos.field_1350;
                
                // Draw from y=-64 to 320
                double minY = -64 - cameraPos.field_1351;
                double maxY = 320 - cameraPos.field_1351;

                Matrix4f model = matrices.method_23760().method_23761();
                
                // Bottom square
                drawLine(model, vertexConsumer, minX, minY, minZ, maxX, minY, minZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, maxX, minY, minZ, maxX, minY, maxZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, maxX, minY, maxZ, minX, minY, maxZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, minX, minY, maxZ, minX, minY, minZ, 0, 0, 1, 1);
                
                // Top square
                drawLine(model, vertexConsumer, minX, maxY, minZ, maxX, maxY, minZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, maxX, maxY, minZ, maxX, maxY, maxZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, maxX, maxY, maxZ, minX, maxY, maxZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, minX, maxY, maxZ, minX, maxY, minZ, 0, 0, 1, 1);
                
                // Vertical lines
                drawLine(model, vertexConsumer, minX, minY, minZ, minX, maxY, minZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, maxX, minY, minZ, maxX, maxY, minZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, maxX, minY, maxZ, maxX, maxY, maxZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, minX, minY, maxZ, minX, maxY, maxZ, 0, 0, 1, 1);
                
                // Draw a big X in the middle at player height for visibility
                double midY = client.field_1724.method_23318() - cameraPos.field_1351;
                drawLine(model, vertexConsumer, minX, midY, minZ, maxX, midY, maxZ, 0, 0, 1, 1);
                drawLine(model, vertexConsumer, minX, midY, maxZ, maxX, midY, minZ, 0, 0, 1, 1);
            }
            // Render virtual blocks
            for (net.minecraft.class_2338 pos : virtualBlocks) {
                double minX = pos.method_10263() - cameraPos.field_1352;
                double minY = pos.method_10264() - cameraPos.field_1351;
                double minZ = pos.method_10260() - cameraPos.field_1350;
                double maxX = minX + 1;
                double maxY = minY + 1;
                double maxZ = minZ + 1;

                Matrix4f model = matrices.method_23760().method_23761();
                
                // Draw red cube outline
                drawLine(model, vertexConsumer, minX, minY, minZ, maxX, minY, minZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, maxX, minY, minZ, maxX, minY, maxZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, maxX, minY, maxZ, minX, minY, maxZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, minX, minY, maxZ, minX, minY, minZ, 1, 0, 0, 1);
                
                drawLine(model, vertexConsumer, minX, maxY, minZ, maxX, maxY, minZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, maxX, maxY, minZ, maxX, maxY, maxZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, maxX, maxY, maxZ, minX, maxY, maxZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, minX, maxY, maxZ, minX, maxY, minZ, 1, 0, 0, 1);
                
                drawLine(model, vertexConsumer, minX, minY, minZ, minX, maxY, minZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, maxX, minY, minZ, maxX, maxY, minZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, maxX, minY, maxZ, maxX, maxY, maxZ, 1, 0, 0, 1);
                drawLine(model, vertexConsumer, minX, minY, maxZ, minX, maxY, maxZ, 1, 0, 0, 1);
            }
        });
    }
    
    private static class VHit {
        net.minecraft.class_2338 pos;
        net.minecraft.class_2350 side;
        boolean isVirtual;
        double distance;
    }

    private static VHit customRaycast(net.minecraft.class_746 player, double maxDist) {
        class_243 start = player.method_5836(1.0F);
        class_243 dir = player.method_5828(1.0F);
        class_243 end = start.method_1019(dir.method_1021(maxDist));

        VHit bestHit = null;

        net.minecraft.class_239 realHit = player.field_17892.method_17742(new net.minecraft.class_3959(start, end, net.minecraft.class_3959.class_3960.field_17559, net.minecraft.class_3959.class_242.field_1348, player));
        if (realHit.method_17783() == net.minecraft.class_239.class_240.field_1332) {
            net.minecraft.class_3965 bhr = (net.minecraft.class_3965) realHit;
            bestHit = new VHit();
            bestHit.pos = bhr.method_17777();
            bestHit.side = bhr.method_17780();
            bestHit.isVirtual = false;
            bestHit.distance = start.method_1022(bhr.method_17784());
        }

        for (net.minecraft.class_2338 vp : virtualBlocks) {
            class_238 box = new class_238(vp);
            java.util.Optional<class_243> vHitOpt = box.method_992(start, end);
            if (vHitOpt.isPresent()) {
                class_243 hitPos = vHitOpt.get();
                double dist = start.method_1022(hitPos);
                if (bestHit == null || dist < bestHit.distance) {
                    bestHit = new VHit();
                    bestHit.pos = vp;
                    bestHit.side = net.minecraft.class_2350.field_11036;
                    if (Math.abs(hitPos.field_1352 - box.field_1323) < 0.001) bestHit.side = net.minecraft.class_2350.field_11039;
                    else if (Math.abs(hitPos.field_1352 - box.field_1320) < 0.001) bestHit.side = net.minecraft.class_2350.field_11034;
                    else if (Math.abs(hitPos.field_1351 - box.field_1322) < 0.001) bestHit.side = net.minecraft.class_2350.field_11033;
                    else if (Math.abs(hitPos.field_1351 - box.field_1325) < 0.001) bestHit.side = net.minecraft.class_2350.field_11036;
                    else if (Math.abs(hitPos.field_1350 - box.field_1321) < 0.001) bestHit.side = net.minecraft.class_2350.field_11043;
                    else if (Math.abs(hitPos.field_1350 - box.field_1324) < 0.001) bestHit.side = net.minecraft.class_2350.field_11035;
                    bestHit.isVirtual = true;
                    bestHit.distance = dist;
                }
            }
        }
        return bestHit;
    }

    private static void drawLine(Matrix4f model, class_4588 vertexConsumer, double x1, double y1, double z1, double x2, double y2, double z2, float r, float g, float b, float a) {
        vertexConsumer.method_22918(model, (float)x1, (float)y1, (float)z1).method_22915(r, g, b, a).method_22914(0, 1, 0);
        vertexConsumer.method_22918(model, (float)x2, (float)y2, (float)z2).method_22915(r, g, b, a).method_22914(0, 1, 0);
    }
}
