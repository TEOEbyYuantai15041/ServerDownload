package com.teoe.wdl.tracker;

import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_638;

public class PathFinder {
    
    private static class Node implements Comparable<Node> {
        class_2338 pos;
        Node parent;
        double g;
        double h;

        Node(class_2338 pos, Node parent, double g, double h) {
            this.pos = pos;
            this.parent = parent;
            this.g = g;
            this.h = h;
        }

        double getF() { return g + h * 1.5; } // Greedy Best-First A* for speed

        @Override
        public int compareTo(Node o) {
            return Double.compare(this.getF(), o.getF());
        }
    }

    public static List<class_2338> findPath(class_638 world, class_2338 start, class_2338 target, int maxNodes) {
        PriorityQueue<Node> openSet = new PriorityQueue<>();
        Set<class_2338> closedSet = new HashSet<>();
        Map<class_2338, Node> allNodes = new HashMap<>();

        Node startNode = new Node(start, null, 0, getHeuristic(start, target));
        openSet.add(startNode);
        allNodes.put(start, startNode);
        
        Node bestNode = startNode;

        int nodesEvaluated = 0;
        
        List<int[]> dirs = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    dirs.add(new int[]{dx, dy, dz});
                }
            }
        }

        while (!openSet.isEmpty() && nodesEvaluated < maxNodes) {
            Node current = openSet.poll();
            closedSet.add(current.pos);
            nodesEvaluated++;
            
            if (current.h < bestNode.h) {
                bestNode = current;
            }

            // Stop if we are strictly adjacent (or diagonal) to the target chest
            int dx = Math.abs(current.pos.method_10263() - target.method_10263());
            int dy = Math.abs(current.pos.method_10264() - target.method_10264());
            int dz = Math.abs(current.pos.method_10260() - target.method_10260());
            if (dx <= 1 && dy <= 1 && dz <= 1) {
                return reconstructPath(current);
            }

            for (int[] dir : dirs) {
                class_2338 neighborPos = current.pos.method_10069(dir[0], dir[1], dir[2]);

                if (closedSet.contains(neighborPos)) continue;

                double cost1 = getPassableCost(world, neighborPos, current.pos);
                double cost2 = getPassableCost(world, neighborPos.method_10084(), current.pos.method_10084());

                // Check if passable (need 2 blocks of vertical space for player's body)
                if (cost1 < 0 || cost2 < 0) {
                    continue;
                }
                
                // Prevent diagonal corner cutting through solid walls
                int changes = Math.abs(dir[0]) + Math.abs(dir[1]) + Math.abs(dir[2]);
                if (changes == 3) {
                    continue; // Disallow 3D diagonals completely to prevent complex clipping
                } else if (changes == 2) {
                    if (dir[0] != 0 && dir[2] != 0) { // XZ diagonal
                        if (getPassableCost(world, current.pos.method_10069(dir[0], 0, 0), current.pos) < 0 || 
                            getPassableCost(world, current.pos.method_10069(0, 0, dir[2]), current.pos) < 0 ||
                            getPassableCost(world, current.pos.method_10069(dir[0], 1, 0), current.pos.method_10084()) < 0 || 
                            getPassableCost(world, current.pos.method_10069(0, 1, dir[2]), current.pos.method_10084()) < 0) {
                            continue;
                        }
                    } else if (dir[0] != 0 && dir[1] != 0) { // XY diagonal
                        if (getPassableCost(world, current.pos.method_10069(dir[0], 0, 0), current.pos) < 0 || 
                            getPassableCost(world, current.pos.method_10069(0, dir[1], 0), current.pos) < 0 ||
                            getPassableCost(world, current.pos.method_10069(dir[0], 1, 0), current.pos.method_10084()) < 0 || 
                            getPassableCost(world, current.pos.method_10069(0, 1 + dir[1], 0), current.pos.method_10084()) < 0) {
                            continue;
                        }
                    } else if (dir[1] != 0 && dir[2] != 0) { // YZ diagonal
                        if (getPassableCost(world, current.pos.method_10069(0, 0, dir[2]), current.pos) < 0 || 
                            getPassableCost(world, current.pos.method_10069(0, dir[1], 0), current.pos) < 0 ||
                            getPassableCost(world, current.pos.method_10069(0, 1, dir[2]), current.pos.method_10084()) < 0 || 
                            getPassableCost(world, current.pos.method_10069(0, 1 + dir[1], 0), current.pos.method_10084()) < 0) {
                            continue;
                        }
                    }
                }

                double stepCost = Math.sqrt(dir[0]*dir[0] + dir[1]*dir[1] + dir[2]*dir[2]) + cost1 + cost2;
                double tentativeG = current.g + stepCost;
                Node neighborNode = allNodes.get(neighborPos);

                if (neighborNode == null) {
                    neighborNode = new Node(neighborPos, current, tentativeG, getHeuristic(neighborPos, target));
                    openSet.add(neighborNode);
                    allNodes.put(neighborPos, neighborNode);
                } else if (tentativeG < neighborNode.g) {
                    neighborNode.parent = current;
                    neighborNode.g = tentativeG;
                    openSet.remove(neighborNode);
                    openSet.add(neighborNode);
                }
            }
        }
        
        if (bestNode != startNode) {
            return reconstructPath(bestNode); // Return the closest path we found
        }
        return null; // Failed completely
    }

    private static double getHeuristic(class_2338 a, class_2338 b) {
        return Math.abs(a.method_10263() - b.method_10263()) + Math.abs(a.method_10264() - b.method_10264()) + Math.abs(a.method_10260() - b.method_10260());
    }

    private static double getPassableCost(class_638 world, class_2338 pos, class_2338 fromPos) {
        if (com.teoe.wdl.tracker.ChunkFilter.virtualBlocks.contains(pos) || 
            com.teoe.wdl.tracker.ChunkFilter.virtualBlocks.contains(pos.method_10084()) || 
            com.teoe.wdl.tracker.ChunkFilter.virtualBlocks.contains(pos.method_10086(2))) {
            return -1.0; // Impassable virtual barrier
        }

        net.minecraft.class_2680 state = world.method_8320(pos);
        net.minecraft.class_2248 block = state.method_26204();

        if (block == net.minecraft.class_2246.field_16541 || 
            block == net.minecraft.class_2246.field_22110 || 
            world.method_8320(pos.method_10084()).method_26204() == net.minecraft.class_2246.field_16541 ||
            world.method_8320(pos.method_10084()).method_26204() == net.minecraft.class_2246.field_22110 ||
            world.method_8320(pos.method_10086(2)).method_26204() == net.minecraft.class_2246.field_16541 ||
            world.method_8320(pos.method_10086(2)).method_26204() == net.minecraft.class_2246.field_22110) {
            return -1.0;
        }

        // Check for dangerous blocks (lava, fire, etc.) that have no collision but kill the player
        if (block == net.minecraft.class_2246.field_10164 || 
            block == net.minecraft.class_2246.field_10036 || 
            block == net.minecraft.class_2246.field_22089 || 
            block == net.minecraft.class_2246.field_17350 || 
            block == net.minecraft.class_2246.field_23860 || 
            block == net.minecraft.class_2246.field_10092 || 
            block == net.minecraft.class_2246.field_16999 || 
            block == net.minecraft.class_2246.field_10029 ||
            !state.method_26227().method_15769() && state.method_26227().method_15767(net.minecraft.class_3486.field_15518)) {
            return -1.0;
        }

        boolean isPassable = state.method_26220(world, pos).method_1110();
        
        // Let's also check if it's a fence or wall and we are walking on it,
        // it shouldn't be passable because its collision goes up to 1.5.
        // If we are at Y=1, and the fence is at Y=0, the fence collision is from Y=0 to Y=1.5.
        // Wait, if pos is Y=1, the block at pos is air.
        // But what if pos is Y=0? The block is fence, collision is not empty, so isPassable is false.
        // This is correct.
        
        // Wait! In the user's image, the player is blocked by a fence.
        // If the player tries to fly over the fence, it would try to move to Y=1 or Y=2.
        // But if the roof is above the fence, the player cannot fit.
        // Let's check vertical clearance explicitly.
        // A player needs 1.8 blocks of height.
        // For a path node, the space from pos to pos.up() must be empty.
        // Actually, cost1 is pos, cost2 is pos.up().
        // If pos is air, cost1=0. If pos.up() is air, cost2=0.
        // But what about the block BELOW pos?
        // If pos is Y=1, downBlock is Y=0 (fence).
        // Fence collision goes up to Y=1.5.
        // The space available from Y=1.5 to the roof at Y=3 is 1.5 blocks!
        // Player height is 1.8, so the player CANNOT FIT between the fence and the roof!
        // But the A* algorithm checks `getPassableCost(pos)` (Y=1) which is AIR (cost1=0),
        // and `getPassableCost(pos.up())` (Y=2) which is AIR (cost2=0).
        // It DOES NOT check if the fence's collision box intrudes into `pos`.
        // So the A* algorithm thinks it can stand on the fence, even though there's only 1.5 blocks of clearance!

        // Let's add a check for the actual collision height of the block below.
        net.minecraft.class_2680 downState = world.method_8320(pos.method_10074());
        double floorY = 0;
        if (!downState.method_26220(world, pos.method_10074()).method_1110()) {
            floorY = downState.method_26220(world, pos.method_10074()).method_1105(net.minecraft.class_2350.class_2351.field_11052) - 1.0;
            if (floorY < 0) floorY = 0;
        }
        
        // Calculate ceiling height from pos.up() or pos.up(2)
        net.minecraft.class_2680 upState = world.method_8320(pos.method_10086(2));
        double ceilY = 2.0;
        if (!upState.method_26220(world, pos.method_10086(2)).method_1110()) {
            double minUp = upState.method_26220(world, pos.method_10086(2)).method_1091(net.minecraft.class_2350.class_2351.field_11052);
            // In case the collision shape is weird
            if (!Double.isInfinite(minUp) && !Double.isNaN(minUp)) {
                ceilY = 2.0 + minUp;
            }
        }
        
        net.minecraft.class_2680 posState = world.method_8320(pos.method_10084());
        if (!posState.method_26220(world, pos.method_10084()).method_1110()) {
            double minPos = posState.method_26220(world, pos.method_10084()).method_1091(net.minecraft.class_2350.class_2351.field_11052);
            if (!Double.isInfinite(minPos) && !Double.isNaN(minPos)) {
                ceilY = Math.min(ceilY, 1.0 + minPos);
            }
        }
        
        // If the clearance is less than 1.5 blocks (sneaking height), it's impassable!
        if (ceilY - floorY < 1.5) {
            return -1.0;
        }

        if (isPassable) {
            if (block == net.minecraft.class_2246.field_10382 || (!state.method_26227().method_15769() && state.method_26227().method_15767(net.minecraft.class_3486.field_15517))) {
                return 15.0; // High penalty for water, only use if absolutely necessary
            }

            // Extra safety: don't fly directly over lava or fire if we are just moving normally
            net.minecraft.class_2248 downBlock = world.method_8320(pos.method_10074()).method_26204();
            if (downBlock == net.minecraft.class_2246.field_10164 || 
                downBlock == net.minecraft.class_2246.field_10092 || 
                downBlock == net.minecraft.class_2246.field_10036 ||
                (!world.method_8320(pos.method_10074()).method_26227().method_15769() && world.method_8320(pos.method_10074()).method_26227().method_15767(net.minecraft.class_3486.field_15518))) {
                return -1.0;
            }
            
            // Add penalty to fences and walls to encourage routing around them
            if (downBlock instanceof net.minecraft.class_2354 || 
                downBlock instanceof net.minecraft.class_2544 || 
                downBlock instanceof net.minecraft.class_2389) {
                return 5.0; // High penalty
            }
            
            return 0.0;
        }
        
        if (block instanceof net.minecraft.class_2323 || 
            block instanceof net.minecraft.class_2533 || 
            block instanceof net.minecraft.class_2349) {
            if (block == net.minecraft.class_2246.field_9973 || 
                block == net.minecraft.class_2246.field_10453) {
                if (state.method_28498(net.minecraft.class_2741.field_12537) && state.method_11654(net.minecraft.class_2741.field_12537)) {
                    return 0.0;
                }
                boolean canTrigger = false;
                if (fromPos != null) {
                    for (int dx = -1; dx <= 1; dx++) {
                        for (int dy = 0; dy <= 2; dy++) {
                            for (int dz = -1; dz <= 1; dz++) {
                                net.minecraft.class_2248 b = world.method_8320(fromPos.method_10069(dx, dy, dz)).method_26204();
                                if (b instanceof net.minecraft.class_2269 || 
                                    b instanceof net.minecraft.class_2401) {
                                    canTrigger = true;
                                    break;
                                }
                            }
                            if (canTrigger) break;
                        }
                        if (canTrigger) break;
                    }
                }
                
                // If there's a pressure plate on the path we are taking, it will open the door!
                if (!canTrigger && fromPos != null) {
                    net.minecraft.class_2248 fromBlock = world.method_8320(fromPos).method_26204();
                    net.minecraft.class_2248 fromDownBlock = world.method_8320(fromPos.method_10074()).method_26204();
                    if (fromBlock instanceof net.minecraft.class_2440 || 
                        fromDownBlock instanceof net.minecraft.class_2440) {
                        canTrigger = true;
                    }
                }

                if (canTrigger) {
                    return 2.0; // Penalty for needing to wait for redstone
                }
                return -1.0; // Impassable if no trigger nearby
            }
            return 1.0; // Penalty for doors/gates
        }
        return -1.0; // Impassable
    }

    private static List<class_2338> reconstructPath(Node node) {
        List<class_2338> path = new ArrayList<>();
        Node current = node;
        while (current != null) {
            path.add(current.pos);
            current = current.parent;
        }
        Collections.reverse(path);
        return path;
    }
}