package com.teoe.wdl.tracker;

import com.teoe.wdl.DownloadManager;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2621;
import net.minecraft.class_310;

public class ChestTracker {
    public static class_2338 lastClickedBlock = null;
    public static final Set<class_2338> savedChests = new HashSet<>();
    public static Set<class_2338> ignoredChests = new HashSet<>();

    public static void saveContainerDirectly(class_2338 targetPos, java.util.List<net.minecraft.class_1799> contents) {
        if (!DownloadManager.isRecording() || !com.teoe.wdl.ConfigManager.saveChests) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;

        class_2586 be = client.field_1687.method_8321(targetPos);
        if (be instanceof class_1263 inv) {
            int containerSize = inv.method_5439();

            if (be instanceof class_2621 lootable) {
                lootable.method_11285(null); // 清除战利品表，这样它就会保存里面的物品
            }

            int realSize = contents.size() - 36;
            if (realSize <= 0) return; // 忽略不是真实容器的发包
            
            for (int i = 0; i < containerSize && i < realSize; i++) {
                inv.method_5447(i, contents.get(i).method_7972());
            }

            // 处理大箱子
            if (realSize > containerSize && be instanceof net.minecraft.class_2595) {
                net.minecraft.class_2680 state = client.field_1687.method_8320(targetPos);
                if (state.method_26204() instanceof net.minecraft.class_2281) {
                    net.minecraft.class_2350 facing = state.method_11654(net.minecraft.class_2281.field_10768);
                    net.minecraft.class_2745 type = state.method_11654(net.minecraft.class_2281.field_10770);
                    
                    class_2338 otherPos = null;
                    if (type == net.minecraft.class_2745.field_12571) {
                        otherPos = targetPos.method_10093(facing.method_10160());
                    } else if (type == net.minecraft.class_2745.field_12574) {
                        otherPos = targetPos.method_10093(facing.method_10170());
                    }

                    if (otherPos != null) {
                        class_2586 otherBe = client.field_1687.method_8321(otherPos);
                        if (otherBe instanceof class_1263 otherInv) {
                            if (otherBe instanceof class_2621 otherLootable) {
                                otherLootable.method_11285(null);
                            }
                            for (int i = 0; i < otherInv.method_5439() && (i + containerSize) < realSize; i++) {
                                otherInv.method_5447(i, contents.get(i + containerSize).method_7972());
                            }
                            savedChests.add(otherPos);
                            class_2487 nbt = otherBe.method_38242(client.field_1687.method_30349());
                            DownloadManager.savedBlockEntitiesCache.put(otherPos, nbt);
                            DownloadManager.saveChunk(new net.minecraft.class_1923(otherPos));
                        }
                    }
                }
            }

            savedChests.add(targetPos);
            class_2487 nbt = be.method_38242(client.field_1687.method_30349());
            DownloadManager.savedBlockEntitiesCache.put(targetPos, nbt);
            DownloadManager.saveChunk(new net.minecraft.class_1923(targetPos));
            
            if (AutoScanner.getCurrentPhase() == AutoScanner.Phase.MANUAL_SCAN) {
                int remaining = 0;
                for (class_2338 pos : ignoredChests) {
                    if (!savedChests.contains(pos)) remaining++;
                }
                client.field_1724.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.chest.saved.remaining", remaining), true);
            } else {
                client.field_1724.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.chest.saved", targetPos.method_23854()), true);
            }
        }
    }
    public static void saveCurrentContainer(class_1703 handler) {
        if (!DownloadManager.isRecording() || lastClickedBlock == null || !com.teoe.wdl.ConfigManager.saveChests) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;

        class_2586 be = client.field_1687.method_8321(lastClickedBlock);
        if (be instanceof class_1263 inv) {
            int containerSize = inv.method_5439();
            if (handler.field_7761.size() < containerSize) return;

            if (be instanceof class_2621 lootable) {
                lootable.method_11285(null); // 清除战利品表，这样它就会保存里面的物品
            }

            // 获取屏幕发来的真实容器大小（刨除玩家背包 36 格）
            int realSize = handler.field_7761.size() - 36;
            if (realSize <= 0) return; // 忽略不是真实容器的发包
            
            for (int i = 0; i < containerSize && i < realSize; i++) {
                inv.method_5447(i, handler.method_7611(i).method_7677().method_7972());
            }

            // 处理大箱子：如果传来的数据大于当前点击的单个箱子
            if (realSize > containerSize && be instanceof net.minecraft.class_2595) {
                net.minecraft.class_2680 state = client.field_1687.method_8320(lastClickedBlock);
                if (state.method_26204() instanceof net.minecraft.class_2281) {
                    net.minecraft.class_2350 facing = state.method_11654(net.minecraft.class_2281.field_10768);
                    net.minecraft.class_2745 type = state.method_11654(net.minecraft.class_2281.field_10770);
                    
                    class_2338 otherPos = null;
                    if (type == net.minecraft.class_2745.field_12571) {
                        otherPos = lastClickedBlock.method_10093(facing.method_10160());
                    } else if (type == net.minecraft.class_2745.field_12574) {
                        otherPos = lastClickedBlock.method_10093(facing.method_10170());
                    }

                    if (otherPos != null) {
                        class_2586 otherBe = client.field_1687.method_8321(otherPos);
                        if (otherBe instanceof class_1263 otherInv) {
                            if (otherBe instanceof class_2621 otherLootable) {
                                otherLootable.method_11285(null);
                            }
                            for (int i = 0; i < otherInv.method_5439() && (i + containerSize) < realSize; i++) {
                                otherInv.method_5447(i, handler.method_7611(i + containerSize).method_7677().method_7972());
                            }
                            savedChests.add(otherPos);
                            class_2487 nbt = otherBe.method_38242(client.field_1687.method_30349());
                            DownloadManager.savedBlockEntitiesCache.put(otherPos, nbt);
                            DownloadManager.saveChunk(new net.minecraft.class_1923(otherPos));
                        }
                    }
                }
            }

            savedChests.add(lastClickedBlock);
            class_2487 nbt = be.method_38242(client.field_1687.method_30349());
            DownloadManager.savedBlockEntitiesCache.put(lastClickedBlock, nbt);
            DownloadManager.saveChunk(new net.minecraft.class_1923(lastClickedBlock));
            
            if (AutoScanner.getCurrentPhase() == AutoScanner.Phase.MANUAL_SCAN) {
                int remaining = 0;
                for (class_2338 pos : ignoredChests) {
                    if (!savedChests.contains(pos)) remaining++;
                }
                client.field_1724.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.chest.saved.remaining", remaining), true);
            } else {
                client.field_1724.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.chest.saved", lastClickedBlock.method_23854()), true);
            }
        }
        
        lastClickedBlock = null;
    }
}