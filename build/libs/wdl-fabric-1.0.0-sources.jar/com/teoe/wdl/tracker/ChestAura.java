package com.teoe.wdl.tracker;

import com.teoe.wdl.DownloadManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2621;
import net.minecraft.class_3965;

public class ChestAura {
    private static int tickDelay = 0;
    public static class_2338 currentTarget = null;
    public static boolean waitingForSync = false;
    public static boolean waitingForInventory = false;
    public static int currentSyncId = -1;
    private static int timeout = 0;

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!DownloadManager.isRecording() || client.field_1724 == null || client.field_1687 == null || !com.teoe.wdl.ConfigManager.saveChests || !AutoScanner.isActive()) {
                currentTarget = null;
                return;
            }

            if (tickDelay > 0) {
                tickDelay--;
                return;
            }

            if (currentTarget != null) {
                // Still waiting... timeout?
                timeout--;
                if (timeout <= 0) {
                    if (client.field_1755 != null) {
                        client.method_1507(null);
                    }
                    if (client.field_1724.field_7512 != null && client.field_1724.field_7512 != client.field_1724.field_7498) {
                        client.field_1724.method_7346();
                    }
                    if (currentTarget != null) {
                        ChestTracker.ignoredChests.add(currentTarget);
                        client.field_1724.method_7353(net.minecraft.class_2561.method_43469("teoe.wdl.chestaura.fail", currentTarget.method_23854()), false);
                    }
                    currentTarget = null;
                    waitingForSync = false;
                    waitingForInventory = false;
                    tickDelay = 1; // 1 tick delay on fail as well
                }
                return;
            }

            // Don't auto open if player is already looking at an inventory manually
            if (client.field_1755 != null && currentTarget == null) {
                return;
            }

            // Check distance first, don't even process if no chests are nearby.
            boolean foundAny = false;
            int chunkX = client.field_1724.method_31476().field_9181;
            int chunkZ = client.field_1724.method_31476().field_9180;
            int renderDistance = client.field_1690.method_38521();
            
            for (int dx = -renderDistance; dx <= renderDistance; dx++) {
                for (int dz = -renderDistance; dz <= renderDistance; dz++) {
                    net.minecraft.class_2818 chunk = client.field_1687.method_2935().method_2857(chunkX + dx, chunkZ + dz, net.minecraft.class_2806.field_12803, false);
                    if (chunk != null) {
                        for (class_2586 be : chunk.method_12214().values()) {
                            class_2338 pos = be.method_11016();
                            if (!ChestTracker.savedChests.contains(pos) && !ChestTracker.ignoredChests.contains(pos)) {
                                if (be instanceof net.minecraft.class_1263 || be instanceof class_2621) {
                                    // Check if chest is reachable (5 blocks distance, squared = 25.0)
                                    if (client.field_1724.method_5707(class_243.method_24953(pos)) < 25.0) {
                                        foundAny = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (foundAny) break;
                }
                if (foundAny) break;
            }
            if (!foundAny) return;

            // Find nearest target
            class_2338 playerPos = client.field_1724.method_24515();
            class_2338 bestTarget = null;
            double bestDist = 25.0; // 5 blocks max check distance (squared = 25.0)
            class_243 playerEyePos = client.field_1724.method_33571();

            for (int dx = -renderDistance; dx <= renderDistance; dx++) {
                for (int dz = -renderDistance; dz <= renderDistance; dz++) {
                    net.minecraft.class_2818 chunk = client.field_1687.method_2935().method_2857(chunkX + dx, chunkZ + dz, net.minecraft.class_2806.field_12803, false);
                    if (chunk != null) {
                        for (class_2586 be : chunk.method_12214().values()) {
                            class_2338 pos = be.method_11016();
                            if (!ChestTracker.savedChests.contains(pos) && !ChestTracker.ignoredChests.contains(pos)) {
                                // Check if it's a lootable container or chest
                                if (be instanceof net.minecraft.class_1263 || be instanceof class_2621) {
                                    double dist = client.field_1724.method_5707(class_243.method_24953(pos));
                                    if (dist < bestDist) { // Must be within 5 blocks
                                        // Ignore line of sight entirely! Just take the closest chest we can reach.
                                        bestDist = dist;
                                        bestTarget = pos;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (bestTarget != null) {
                currentTarget = bestTarget;
                ChestTracker.lastClickedBlock = bestTarget;
                timeout = 40; // 2 seconds timeout
                waitingForSync = true;
                waitingForInventory = false;
                
                class_3965 hitResult = new class_3965(
                        new class_243(bestTarget.method_10263() + 0.5, bestTarget.method_10264() + 0.5, bestTarget.method_10260() + 0.5),
                        class_2350.field_11036, bestTarget, false);
                        
                // Get accurate hit result from raycast if possible
                class_3965 raycastResult = client.field_1687.method_17742(new net.minecraft.class_3959(
                        playerEyePos, new class_243(bestTarget.method_10263() + 0.5, bestTarget.method_10264() + 0.5, bestTarget.method_10260() + 0.5), 
                        net.minecraft.class_3959.class_3960.field_17559, 
                        net.minecraft.class_3959.class_242.field_1348, 
                        client.field_1724));
                
                if (raycastResult.method_17783() == net.minecraft.class_239.class_240.field_1332 && raycastResult.method_17777().equals(bestTarget)) {
                    hitResult = raycastResult;
                } else {
                    // Force the block pos to be exactly the target, to make sure interactBlock is pointing to the block!
                    hitResult = new class_3965(
                        new class_243(bestTarget.method_10263() + 0.5, bestTarget.method_10264() + 0.5, bestTarget.method_10260() + 0.5),
                        class_2350.field_11036, bestTarget, true); // inside block
                }

                // If raycast failed but we are close, use a default visible direction
                if (hitResult.method_17780() == null) {
                    hitResult = hitResult.method_17779(class_2350.field_11036);
                }

                // Silent fast packet sending
                int sequence = 0;
                client.method_1562().method_52787(new net.minecraft.class_2885(class_1268.field_5808, hitResult, sequence));
                
                // client.player.sendMessage(net.minecraft.text.Text.translatable("teoe.wdl.chestaura.trying", bestTarget.toShortString(), "SILENT"), false);
                // No swinging hand or chat messages to make it completely invisible and fast!
            }
        });
    }
}