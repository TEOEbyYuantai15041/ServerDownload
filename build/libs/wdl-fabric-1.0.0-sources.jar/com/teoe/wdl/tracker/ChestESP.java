package com.teoe.wdl.tracker;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import java.util.List;

public class ChestESP {
    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null || !com.teoe.wdl.DownloadManager.isRecording()) return;

            // Show current target chest
            class_2338 target = AutoScanner.currentChestTarget;
            if (target == null) target = ChestAura.currentTarget;

            if (target != null) {
                // Spawn gold/yellow particles around the target
                double x = target.method_10263() + 0.5;
                double y = target.method_10264() + 0.5;
                double z = target.method_10260() + 0.5;
                
                client.field_1713.method_3056(class_2398.field_11211, x, y + 0.6, z, 0.0, 0.05, 0.0);
                client.field_1713.method_3056(class_2398.field_11207, x, y, z, 0.0, 0.01, 0.0);
            }

            // Show path if exists
            List<class_2338> path = AutoScanner.getCurrentChestPath();
            if (path != null && !path.isEmpty()) {
                for (class_2338 node : path) {
                    client.field_1713.method_3056(class_2398.field_23114, node.method_10263() + 0.5, node.method_10264() + 0.2, node.method_10260() + 0.5, 0.0, 0.01, 0.0);
                }
            }
        });
    }
}