package com.teoe.wdl.server;

import javax.imageio.ImageIO;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MapGenerator {
    // Stores the 16x16 RGB map colors for each downloaded chunk
    public static final Map<class_1923, int[]> chunkColors = new ConcurrentHashMap<>();
    
    private static int minChunkX = Integer.MAX_VALUE;
    private static int minChunkZ = Integer.MAX_VALUE;
    private static int maxChunkX = Integer.MIN_VALUE;
    private static int maxChunkZ = Integer.MIN_VALUE;

    public static void clear() {
        chunkColors.clear();
        minChunkX = Integer.MAX_VALUE;
        minChunkZ = Integer.MAX_VALUE;
        maxChunkX = Integer.MIN_VALUE;
        maxChunkZ = Integer.MIN_VALUE;
    }

    public static int getMinChunkX() { return minChunkX; }
    public static int getMinChunkZ() { return minChunkZ; }
    public static int getMaxChunkX() { return maxChunkX; }
    public static int getMaxChunkZ() { return maxChunkZ; }

    public static void updateChunk(class_2818 chunk) {
        if (chunk == null) return;
        class_1923 pos = chunk.method_12004();
        int[] colors = new int[256];
        
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int height = chunk.method_12005(class_2902.class_2903.field_13202, x, z);
                class_2338 topPos = new class_2338(pos.method_8326() + x, height - 1, pos.method_8328() + z);
                net.minecraft.class_2680 state = chunk.method_8320(topPos);
                
                // Get the MapColor of the block
                int baseColor = state.method_26205(class_310.method_1551().field_1687, topPos).field_16011;
                
                // Calculate basic shading based on height variation (similar to vanilla maps)
                // We'll compare with the height of the block to the north (z - 1)
                int northHeight = height;
                if (z > 0) {
                    northHeight = chunk.method_12005(class_2902.class_2903.field_13202, x, z - 1);
                } else {
                    // For cross-chunk boundaries, just use current height to avoid complex lookups
                    northHeight = height;
                }
                
                double shadeModifier = 1.0;
                if (height > northHeight) {
                    shadeModifier = 1.2; // Brighter
                } else if (height < northHeight) {
                    shadeModifier = 0.8; // Darker
                }
                
                // Special handling for water depth (approximate)
                if (state.method_26227().method_39360(net.minecraft.class_3612.field_15910) || state.method_26227().method_39360(net.minecraft.class_3612.field_15909)) {
                    int oceanFloor = chunk.method_12005(class_2902.class_2903.field_13200, x, z);
                    int depth = height - oceanFloor;
                    if (depth > 10) shadeModifier *= 0.7;
                    else if (depth > 5) shadeModifier *= 0.85;
                    else shadeModifier *= 1.1; // Shallow water is brighter
                }

                int r = (int) (((baseColor >> 16) & 0xFF) * shadeModifier);
                int g = (int) (((baseColor >> 8) & 0xFF) * shadeModifier);
                int b = (int) ((baseColor & 0xFF) * shadeModifier);
                
                r = Math.min(255, Math.max(0, r));
                g = Math.min(255, Math.max(0, g));
                b = Math.min(255, Math.max(0, b));
                
                colors[z * 16 + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        
        chunkColors.put(pos, colors);
        
        synchronized (MapGenerator.class) {
            if (pos.field_9181 < minChunkX) minChunkX = pos.field_9181;
            if (pos.field_9181 > maxChunkX) maxChunkX = pos.field_9181;
            if (pos.field_9180 < minChunkZ) minChunkZ = pos.field_9180;
            if (pos.field_9180 > maxChunkZ) maxChunkZ = pos.field_9180;
        }
    }

    public static byte[] generateMapJpg() {
        if (chunkColors.isEmpty()) {
            return new byte[0];
        }

        int widthChunks, heightChunks;
        int localMinX, localMinZ;
        
        synchronized (MapGenerator.class) {
            localMinX = minChunkX;
            localMinZ = minChunkZ;
            widthChunks = maxChunkX - minChunkX + 1;
            heightChunks = maxChunkZ - minChunkZ + 1;
        }

        // Prevent OOM for insanely large maps. Limit to 8192x8192 pixels (512x512 chunks)
        if (widthChunks > 512) widthChunks = 512;
        if (heightChunks > 512) heightChunks = 512;

        int pixelWidth = widthChunks * 16;
        int pixelHeight = heightChunks * 16;

        BufferedImage image = new BufferedImage(pixelWidth, pixelHeight, BufferedImage.TYPE_INT_RGB);

        for (Map.Entry<class_1923, int[]> entry : chunkColors.entrySet()) {
            class_1923 pos = entry.getKey();
            int[] colors = entry.getValue();

            int chunkOffsetX = pos.field_9181 - localMinX;
            int chunkOffsetZ = pos.field_9180 - localMinZ;

            if (chunkOffsetX >= 0 && chunkOffsetX < widthChunks && chunkOffsetZ >= 0 && chunkOffsetZ < heightChunks) {
                int startPixelX = chunkOffsetX * 16;
                int startPixelZ = chunkOffsetZ * 16;

                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        image.setRGB(startPixelX + x, startPixelZ + z, colors[z * 16 + x]);
                    }
                }
            }
        }

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(image, "jpg", baos);
            return baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return new byte[0];
        }
    }
}
