package com.teoe.wdl;

import java.io.DataOutputStream;
import java.io.File;
import java.nio.file.Files;
import net.minecraft.class_1297;
import net.minecraft.class_155;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_638;

public class EntitySaver {
    public static void saveEntitiesToRegion(File regionDir, class_1923 pos, class_2487 entitiesNbt) {
        int regionX = pos.field_9181 >> 5;
        int regionZ = pos.field_9180 >> 5;
        File mcaFile = new File(regionDir, "r." + regionX + "." + regionZ + ".mca");

        try {
            try (net.minecraft.class_2861 region = new net.minecraft.class_2861(new net.minecraft.class_9240("wdl", net.minecraft.class_5321.method_29179(net.minecraft.class_7924.field_41223, net.minecraft.class_2960.method_60655("minecraft", "overworld")), "entities"), mcaFile.toPath(), regionDir.toPath(), true)) {
                try (DataOutputStream out = region.method_21881(pos)) {
                    net.minecraft.class_2507.method_55324(entitiesNbt, out);
                }
                region.method_26981();
            }
        } catch (Exception e) {
            System.err.println("Failed to save entities " + pos);
            e.printStackTrace();
        }
    }

    public static class_2487 serializeEntities(class_638 world, class_1923 pos, File baseDir, net.minecraft.class_5455 registryManager) {
        class_2487 root = new class_2487();
        root.method_10569("DataVersion", class_155.method_16673().comp_4026().comp_4038());
        root.method_10539("Position", new int[]{pos.field_9181, pos.field_9180});
        
        class_2499 entitiesList = new class_2499();
        net.minecraft.class_238 box = new net.minecraft.class_238(
            pos.method_8326(), -64, pos.method_8328(),
            pos.method_8327(), 320, pos.method_8329()
        );
        
        for (class_1297 entity : world.method_8335(null, box)) {
            if (entity instanceof net.minecraft.class_746) continue;
            
            net.minecraft.class_11362 writeView = net.minecraft.class_11362.method_71459(net.minecraft.class_8942.field_60348, registryManager);
            try {
                if (!entity.method_5786(writeView)) {
                    if (entity instanceof net.minecraft.class_745) {
                        entity.method_5647(writeView); // Fake players won't save via saveSelfData, so we force writeData
                    } else {
                        continue;
                    }
                }
            } catch (Exception ignored) { continue; }
            class_2487 entityNbt = writeView.method_71475();
            
            if (entity instanceof net.minecraft.class_745 fakePlayer) {
                String prefix = ConfigManager.fakePlayerPrefix;
                if (prefix != null && !prefix.isEmpty() && fakePlayer.method_5477().getString().startsWith(prefix)) {
                    try {
                        File playerDataDir = new File(baseDir, "playerdata");
                        playerDataDir.mkdirs();
                        File playerFile = new File(playerDataDir, fakePlayer.method_5845() + ".dat");
                        net.minecraft.class_2507.method_30614(entityNbt, playerFile.toPath());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                if (entityNbt != null && !entityNbt.method_33133()) {
                    entitiesList.add(entityNbt);
                }
            }
        }
        
        root.method_10566("Entities", entitiesList);
        return root;
    }
}
